#!/usr/bin/ksh
#
#      Filename:  find_libary_cache.sh
#
#      Description:  Automatic monitoring of the PROD database
#                    for the existence of following two:
#			library cache: mutex X
#			library cache lock
#
# #======================================================================
#
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi
sqlplus -s /nolog <<EOF > find_library_cache.log
connect $USERID2
	set feed off
     	set head off
select count(event) from v\$session_wait 
where event ='library cache: mutex X'
group by event;
     exit
EOF
sqlplus -s /nolog <<EOF > find_library_cache_1.log 
connect $USERID2     
select event, count(event) from v\$session_wait 
where event like 'library%'
group by event;
     exit
EOF
# Check if the number in find_library_cache.log is greater than 10
if [ `cat find_library_cache.log` -gt 10 ]
then
echo "Library cache found.">> find_library_cache_1.log
# Email notification to the designated user(s). 
mailx -s 'Library Cache Issue Alert' $MAIL_USER11 < find_library_cache_1.log
# Record the date and log it into a statistics file
date >> find_library_cache_1.log
cat find_library_cache_1.log >> /home/oraprod/scripts/log/library_cache_history.log
fi
# end-of-script
#
