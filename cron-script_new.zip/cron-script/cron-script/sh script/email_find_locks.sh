#
# #======================================================================
DBA_EMAIL='david.fei@paxar.com eric.wang@paxar.com'
HOST=`hostname`
DIR=`dirname $0`
if [ -z $DIR ] ; then
DIR=`pwd`
fi
export DIR
export LOG_FILE=$DIR/log/locked_sessions`date +%m%d%y`.log
if [ ! -f $LOG_FILE ] ; then
touch $LOG_FILE
fi
#
. /u01/oracle/proddb/9.2.0/PROD_pxrdb2.env
sqlplus -s apps/mysox222@PROD <<EOF > temp$$
set pagesize 1000
col sid for a15
col spid for a8
col process for a8
col module for a10
col machine for a35
SELECT DECODE(lk.request,0,'Holder: ','Waiter: ')||lk.sid sid, sn.serial#, 
ps.spid, sn.process, sn.action, sn.module, sn.machine
FROM V\$LOCK lk, v\$session sn, v\$process ps
WHERE (lk.id1, lk.id2, lk.type) IN
(SELECT id1, id2, type FROM V\$LOCK WHERE request>0)
and sn.paddr = ps.addr
and lk.sid (+) = sn.sid
ORDER BY lk.id1, lk.request;
exit
EOF
sed -e '1d' temp$$ > locked_sessions.log
if [`wc -l < locked_sessions.log` -gt 4 ]
then
date >> $LOG_FILE 
echo "Locked Sessions at this time: " >> $LOG_FILE
cat locked_sessions.log >> $LOG_FILE
echo "===========================================================================================  Currently your session is blocking others. Please could you exit and relogin to Oracle application to help release the blocking.

Thanks for your immediate attention. Should I not hear from you, I would have to terminate your session." >> locked_sessions.log
mailx -s 'Sessions Locked in PROD' $DBA_EMAIL < locked_sessions.log
fi
trap 'rm temp$$' 0 2 3 15
# end-of-script
