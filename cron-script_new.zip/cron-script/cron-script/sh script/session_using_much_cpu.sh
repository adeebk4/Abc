#!/usr/bin/ksh
#               Filename:       session_using_much_cpu.sh
#
#               Description:    Finding sessions that use much CPU
#
# define env variables
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting session_using_much_cpu.sh"
        exit
fi
sqlplus -s $USERID1 <<EOF > $DIR1/log/sessions_using_much_cpu.log
set lines 400 pages 100
col module for a28
col event for a28
col action for a28
select
   se.SID,
   ss.process,
   ps.spid,
   ss.module,
   ss.event,
   ss.action,
   ss.sql_id,
   VALUE/6000 cpu_usage_minutes
from
   v\$session ss,
   v\$process ps,
   v\$sesstat se,
   v\$statname sn
where
   se.STATISTIC# = sn.STATISTIC#
and
   NAME like '%CPU used by this session%'
and
   se.SID = ss.SID
and
   ss.status='ACTIVE'
and
   ss.username is not null
and ss.paddr = ps.addr
and VALUE/100 > 5000
order by VALUE desc
/
exit
EOF
if [`wc -l < $DIR1/log/sessions_using_much_cpu.log` -gt 3 ]
then
echo "High CPU session(s) found in PROD Instance. DBA attention is needed." >> $DIR1/log/sessions_using_much_cpu.log
mailx -s 'High CPU Session Found in PROD' $MAIL_USER0 < $DIR1/log/sessions_using_much_cpu.log
fi
# End-of_file
