#!/bin/sh
#####################################################################
###   START OF UNIX SCRIPT                                        ###
#####################################################################

## Define env variables
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi

#
cd /home/oraprod/work/log
LOG_FILE="gs_item_cat.log"
(
     echo "Collecting Stats...."
     date
     sqlplus -s $USERID2 @/home/oraprod/scripts/gs_item_cat.sql
     echo "Done"
     date
) | tee $LOG_FILE     
#
#####################################################################
###   END OF UNIX SCRIPT                                          ###
#####################################################################

