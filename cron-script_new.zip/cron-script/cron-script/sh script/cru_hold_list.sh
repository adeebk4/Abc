#!/usr/bin/ksh
#
#       Filename:  Db_stale_usrs_lst.sh
#       Description:  Database Stale Users List
#
##=========================================================================================
#
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi
#

req_count=`sqlplus -silent  $USERID2<<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
select count(1)
from fnd_concurrent_requests a,
fnd_user b,
fnd_user d,
fnd_concurrent_programs_tl c
where
A.status_code in ('Q','I')
and A.phase_code='P'
and a.requested_by=b.user_id
and a.last_updated_by=d.user_id
And a.concurrent_program_id=c.concurrent_program_id
and c.language = 'US'
and a.hold_flag='Y'
and (b.user_name like 'CRU%' or  a.last_updated_by<>a.requested_by);
EXIT;
EOF`
echo $req_count

if [[ $req_count -ge 1 ]]; then

sqlplus -s /nolog <<EOF > /dev/null
connect $USERID2
set linesize 250 pagesize 150
SET MARKUP HTML ON SPOOL ON
SET ECHO OFF
SET MARKUP HTML ON SPOOL ON
SPOOL "/home/oraprod/scripts/UL.html"
Prompt List of concurrent requests on hold in PROD 
select a.request_id, b.user_name,d.user_name hold_by, c.user_concurrent_program_name program_name, a.argument_text, requested_start_date
from fnd_concurrent_requests a,
fnd_user b,
fnd_user d,
fnd_concurrent_programs_tl c
where
A.status_code in ('Q','I')
and A.phase_code='P'
and a.requested_by=b.user_id
and a.last_updated_by=d.user_id
And a.concurrent_program_id=c.concurrent_program_id
and c.language = 'US'
and a.hold_flag='Y'
and (b.user_name like 'CRU%' or  a.last_updated_by<>a.requested_by)
order by request_id desc ;
spool off
exit
EOF
export MAILTO="prasanna.ramanujam@ap.averydennison.com","oracle_dbas@averydennison.com","Oracle_SCM@ap.averydennison.com","Oracle.FIN@ap.averydennison.com","oracle.tech@ap.averydennison.com"
#export MAILTO="roger.feng@ap.averydennison.com"
export CONTENT="/home/oraprod/scripts/UL.html"
export SUBJECT="There are $req_count Requests on Hold in PROD"
(
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat $CONTENT
) | /usr/sbin/sendmail $MAILTO
echo "mail sent"
fi
