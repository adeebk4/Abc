#!/bin/ksh
# script cleanup_px_tables.sh (used to be cleanup_px_schedule_date_alert.sh)
# For cleaning up the PAXAR.PX_SCHEDULE_DATE_ALERT table. Run weekly for PX Schedule Date Change alerts performance
# The DELETE statement had been agreed by Greg Madden on Dec 8, 2006 
# Script created by EW, Dec 12, 2006
#
# Added "Delete from paxar.PX_FND_CONC_REQ_HISTORY ..." to the initial script cleanup_px_schedule_date_alert.sh 
# and renamed it to cleanup_px_tables.sh 	by EW, Jan 16, 2009

date
. /home/oraprod/work/all_PROD.env
echo "Delete date older than 2 weeks from PAXAR.PX_SCHEDULE_DATE_ALERT ..."
sqlplus -s $USERID2  <<EOF 
delete from PAXAR.PX_SCHEDULE_DATE_ALERT WHERE RUN_DATE < SYSDATE - 14;
select 'Rows remaining: '||count(*) from PAXAR.PX_SCHEDULE_DATE_ALERT;
commit;
-- gather stats after the above changes in data
exec fnd_stats.gather_table_stats (ownname => 'PAXAR', tabname => 'PX_SCHEDULE_DATE_ALERT');
exit
EOF

echo "DELETE data older than 60 days from paxar.PX_FND_CONC_REQ_HISTORY..." 
sqlplus -s $USERID2  <<EOF
delete from paxar.PX_FND_CONC_REQ_HISTORY where actual_completion_date  < sysdate - 60;
select 'Rows remaining: '||count(*) from PAXAR.PX_FND_CONC_REQ_HISTORY where actual_completion_date  < sysdate;
commit;
alter index paxar.PX_FND_CONC_REQ_HISTORY_C1 rebuild online;
-- gather stats after the above changes in data
exec fnd_stats.gather_table_stats (ownname => 'PAXAR', tabname => 'PX_FND_CONC_REQ_HISTORY', cascade => TRUE);
exit
EOF

# End of script
