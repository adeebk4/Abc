#!/usr/bin/ksh
#
#      Filename:  kill_inactive_forms_4hrs.sh
#      Description: Checks and Kill the inactive form sessions > 4hrs.
#                   Identification of blocking session for certain waiting sessions.
#      Developed by: OraAdmin
#      Date of Creation: April 30, 2019
#
# #======================================================================
# Define env variables
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting kill_inactive_forms_2hrs.sh"
        exit
fi
export KILL_LOG_FILE=$DIR1/log/kill_sessions`date +%m%d%y`.log
if [ ! -f $KILL_LOG_FILE ] ; then
touch $KILL_LOG_FILE
fi
#
# Get a list of inactive form sessions >4hrs
#BENCHAN
sqlplus -s /nolog <<EOF > $DIR1/kill_inactive_form_session.log
connect / as sysdba
set trimspool on
set lines 300
set feed off
set pagesize 1000
col action for a20 truncate
col machine for a8
col CLIENT_IDENTIFIER for a20
col sid format  99999
col username format a10
col serial# for 99999
col sql_id for a16
col module for a22 
col machine for a8
select to_char(sysdate,'Dd-Mon-Yyyy Hh24:Mi:ss') "SYSDATE" from dual;
select sid,serial#,sql_id,machine,username,module,action,CLIENT_IDENTIFIER, status 
from v\$session s 
where status like 'INACTIVE' 
and logon_time < sysdate-2/24 
and module like '%frm%'
and last_call_et/60>240;
exit
EOF

# Generate sql kill script.
sqlplus -s $USERID2 <<EOF > $DIR1/inactive_form_session_to_kill.sql
set head off
set echo off
set feed off
set serveroutput off
set pagesize 1000
SELECT 'ALTER SYSTEM KILL SESSION '||Chr(39)||s.sid||','||s.serial#|| Chr(39)||' immediate;'
from v\$session s 
where status like 'INACTIVE' 
and logon_time < sysdate-4/24 
and module like '%frm%'
and last_call_et/60>240;
exit
EOF

# Record this event in the logfile.
cat $DIR1/kill_inactive_form_session.log >> $KILL_LOG_FILE


# Execute sql kill script.
sqlplus -s /nolog <<EOF
connect / as sysdba
@$DIR1/inactive_form_session_to_kill.sql;
exit
EOF

#Remove the temporary log file
rm $DIR1/kill_inactive_form_session.log
