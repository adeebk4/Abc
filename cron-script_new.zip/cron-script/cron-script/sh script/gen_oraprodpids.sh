ps -ef | grep oraprod |grep LOCAL | cut -c 10-15 > orapids
