#!/bin/ksh

if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi

sqlplus -s /nolog <<EOF
connect $USERID2
SET ECHO OFF
set pages 1000
set feedback off
SET MARKUP HTML ON SPOOL ON
SPOOL /home/oraprod/scripts/LRP.html
@/home/oraprod/scripts/longreq.sql
spool off
exit
EOF
export MAILTO="prasanna.ramanujam@ap.averydennison.com","shiva.prasad@averydennison.com","roger.feng@ap.averydennison.com","tanmayee.patro@ap.averydennison.com"," muralidharreddy.mallu@ap.averydennison.com"
export CONTENT="/home/oraprod/scripts/LRP.html"
export SUBJECT="PROD:LONG RUNNING CONCURRENT PROGRAMS"
(
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat $CONTENT
) | /usr/sbin/sendmail $MAILTO
