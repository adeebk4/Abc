SELECT trunc((sysdate - Fcr.actual_start_date) * 24, 2) "Running_since(Hrs)" ,Fcr.Request_Id Request_id,fu.User_name "Submitted By",fu.email_address "Mail_id",Fcpv.User_Concurrent_Program_Name  "Program", Fcr.Argument_text "PARAMETERS",
to_char(Fcr.ACTUAL_START_DATE,'DD-MM-YY Hh24:Mi:ss') "STARTED"
FROM  apps.Fnd_Concurrent_Requests Fcr , apps.Fnd_Concurrent_Programs Fcp , apps.Fnd_User Fu , apps.Fnd_Concurrent_Processes Fpro , apps.Fnd_Concurrent_Programs_Vl Fcpv 
where (sysdate - Fcr.actual_start_date) * 24 > 3
and Fcr.status_code ='R'
and Fcr.phase_code ='R'
AND fcr.requested_by = user_id 
AND fcr.Controlling_Manager = Concurrent_Process_Id  
AND (fcr.concurrent_program_id = fcp.concurrent_program_id AND fcr.program_application_id = fcp.application_id ) 
AND (fcr.concurrent_program_id = fcpv.concurrent_program_id AND fcr.program_application_id = fcpv.application_id )
AND Fcr.concurrent_program_id not in (31556,33733) 
order by 1 desc;
