#!/usr/bin/ksh
#
#      Filename:  WF_notification_chk_bounce.sh
#
#      Description: Monitor and bounce mailer
#                    
# #======================================================================
#

if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi


#LOG_FILE=/home/oraprod/scripts/log/WF_restart.log
sqlplus -s /nolog <<EOF > temp$$
connect $USERID2
     set  head off
     select count(*) from wf_notifications
     where mail_status='MAIL';
     exit
EOF
sed -e '1d' temp$$ > notification.log
# Check if the number in notification.log is greater than 200
if [`cat notification.log` -gt 200 ]
then
echo "Number of emails waiting to go indicates possible email notification down.Please check email notification in Oracle Application Manager." >> notification.log
mailx -s 'MAIL_STATUS = MAIL in WF_NOTIFICATIONS' $MAIL_USER6 < notification.log
sqlplus -s $USERID2 @WF_restart.sql
fi
#
trap 'rm temp$$' 0 2 3 15
# end-of-script
#
