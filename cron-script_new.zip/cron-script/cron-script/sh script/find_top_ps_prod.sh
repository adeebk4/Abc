####################################################################
# file: find_ps_prod.sh
# usage:  find_ps_prod.sh
# find form or request session information for top CPU consuming 
# oracle parent and child processes, and possible runaway processes.
# 8/2001
# modified the main sql statement to a single query return format for the sessions and to include 
# checking and notifying for runaway processes for forms sessions. 4/2003
#####################################################################

HOST=`hostname`
DIR=`dirname $0`
if [ -z $DIR ] ; then
DIR=`pwd`
fi
export DIR
export LOG_FILE=$DIR/log/top_ps`date +%m%d%y`.log
if [ ! -f $LOG_FILE ] ; then
touch $LOG_FILE
fi

# Oracle server code
. /u01/oracle/proddb/9.2.0/PROD_pxrdb2.env

ps -ef|sort +3 -r|grep oraprod|grep oraclePROD|head -n +10 > $DIR/top_oraprod_10.txt
awk '{ print $2 }' $DIR/top_oraprod_10.txt >$DIR/top_cpu_oraprod.txt
# ps -ef|sort +3 -r |grep applprod|head -n +10 >top_cpu_applprod.txt
# 
# # uncomment the following lines to generate the scripts. 
cat <<EOF > $DIR/apps_session.sql
set pages 0 verify off feed off lines 90
col  user_name for a12 truncate
col ora_pid  for a8 
col os_pid for a8
col type for a11
col machine for a9
col program for a30 truncate
select oracle_process_id ora_pid, os_process_id os_pid, 'Concurrent' type, 
b.user_name user_name, 'pxrdb2' machine, user_concurrent_program_name program  
from fnd_concurrent_requests a, fnd_user b, 
fnd_concurrent_programs_tl c
where a.requested_by=b.user_id
and a.concurrent_program_id=c.concurrent_program_id
and c.language= 'US'
and phase_code = 'R' 
and oracle_process_id=&&1
UNION ALL
select process_spid ora_pid, nvl(process,'NA') os_pid, 'Forms' type, user_name, 
nvl(machine,'NA') machine, user_form_name program
from fnd_form_sessions_v a, v\$session b
where a.sid=b.sid (+) and a.serial#=b.serial# (+)
and process_spid=&&1
/
exit
EOF

cat <<EOF >$DIR/unknown_session.sql
set pages 0 verify off feed off lines 90
col  user_name for a12 truncate
col ora_pid  for a8
col os_pid for a8
col type for a11
col machine for a9
col program for a30 truncate
select spid ora_pid, process os_pid, 'Unknown' type, osuser user_name, machine, module program
 from v\$process a, v\$session b
where a.addr=b.paddr
and spid=&&1
/
exit
EOF

rm $DIR/top_session_info.txt 2>/dev/null
rm $DIR/runaway_session.txt 2>/dev/null
touch $DIR/runaway_session.txt

for P in `cat $DIR/top_cpu_oraprod.txt`
do
	sqlplus -s apps/mysox222 @$DIR/apps_session.sql $P >$DIR/session_info
	if [ -s $DIR/session_info ] ; then
		awk '{ print $2 }' $DIR/session_info|read OS_PID
		awk '{ print $5 }' $DIR/session_info|read HOST
		rsh $HOST   ps -ef|grep $OS_PID|grep -v grep >/dev/null 2>/dev/null
		if [ $? -ne 0 -o $OS_PID = 'NA' ] ; then
          		echo "Parent process $OS_PID on $HOST for shadow process $P does not exist." >>$DIR/runaway_session.txt
		fi
	else
		sqlplus -s apps/mysox222 @$DIR/unknown_session.sql $P >$DIR/session_info
	fi
	cat $DIR/session_info >>$DIR/top_session_info.txt
	rm $DIR/session_info 2>/dev/null
done

date >> $LOG_FILE 
echo "Top 10 CPU concuming oraprod sessions: " >> $LOG_FILE
echo "     UID    PID   PPID   C    STIME    TTY  TIME CMD" >> $LOG_FILE
cat $DIR/top_oraprod_10.txt >> $LOG_FILE
echo Detailed top session info: >> $LOG_FILE
echo "ORA_PID  OS_PID    Type       USER_NAME  MACHINE   PROGRAM                      " >> $LOG_FILE
echo "-------- -------- ---------- ---------- --------- ------------------------------" >> $LOG_FILE
cat $DIR/top_session_info.txt >> $LOG_FILE

if [ -s $DIR/runaway_session.txt ] ; then
# 	cat $DIR/runaway_session.txt |mail -s "Alert: Runaway sessions detected" "eric.wang@paxar.com david.fei@paxar.com"
	echo "Top CPU consuming oraprod processes that are running away:">> $LOG_FILE
	cat $DIR/runaway_session.txt >> $LOG_FILE
fi

# clean up
rm $DIR/top_oraprod_10.txt 2>/dev/null
rm $DIR/top_session_info.txt 2>/dev/null
rm $DIR/runaway_session.txt 2>/dev/null
