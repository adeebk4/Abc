#!/usr/bin/ksh

if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi
sqlplus -s /nolog <<EOF > /dev/null
connect $USERID2
set pagesize 100
SPOOL /home/oraprod/work/log/gs1.log;
@/home/oraprod/scripts/gs1.sql;
spool off;
exit
EOF

# end-of-script
#

