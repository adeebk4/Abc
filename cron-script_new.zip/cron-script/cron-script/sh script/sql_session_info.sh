# environment setup
. /u02/oracle/oraprod/work/all_PROD.env

HOST=`hostname`
DIR=`dirname $0`
if [ -z $DIR ] ; then
DIR=`pwd`
fi
export DIR
export LOG_FILE=$DIR/log/sql_sess_info_`date +%m%d%y`.log

date >>$LOG_FILE
sqlplus -s $USERID2 << EOF >$DIR/sql_session.lst
set pages 20 lines 130 feed off echo off head off
col process for a10
col username for a12 trunc
col program for a20 trunc
col module for a15 truncate
col machine for a15 trunc
select sid, username, process, NVL(module,'NULL') module, program, machine, sql_hash_value from v\$session 
-- where sql_hash_value = '1743114230' 
where sql_hash_value in (select hash_value from v\$sqlarea where sql_text like 'select rc.customer_id, ooh.ordered_date,ra.city%')
/
exit
EOF

# if no module information, try "ps -ef" to see if there is something
if [ -s $DIR/sql_session.lst ] ; then
	if [ ! -f $LOG_FILE ] ; then
		touch $LOG_FILE
	fi

	date >>$LOG_FILE
	cat $DIR/sql_session.lst >>$LOG_FILE
#	echo $(awk '{ print $4 }' $DIR/sql_session.lst)
	if [ $(awk '{ print $4 }' $DIR/sql_session.lst) = 'NULL' ] ; then
		P=$(awk '{ print $3 }' $DIR/sql_session.lst)
		ps -ef|grep $P|grep -v grep >>$LOG_FILE 2>>$LOG_FILE
	fi
	rm $DIR/sql_session.lst
fi
return 0
