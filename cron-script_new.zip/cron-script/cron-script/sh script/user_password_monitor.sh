
#!/usr/bin/ksh
#
#      Filename:  user_password_monitor.sh
#
#      Descriptions: This script is used to monitor the user password exirations
#		     When a user's password is to be expired within 14 days, an
#		     email is to be sent to the DBAs in order to notify this
#                    user to reset his or her password. 
# #======================================================================
# Define env variables
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script."
        exit
fi
# export USER_PASSWORD_EXPIRE_MONITOR_LOG=$DIR1/log/USER_PASS_MINITOR`date +%m%d%y`.log
# if [ ! -f $USER_PASSWORD_EXPIRE_MONITOR_LOG ] ; then
# touch $USER_PASSWORD_EXPIRE_MONITOR_LOG
# fi
#
sqlplus -s /nolog <<EOF > temp$$
connect $USERID2
set head off
select count(*)
from dba_users
where expiry_date-sysdate < 14
and expiry_date-sysdate > 0;
exit
EOF
sed -e '1d' temp$$ > user_pass_expire.log
if [`cat user_pass_expire.log` -gt 0 ]
then
echo "The following user account(s) due to expire soon. Please advise the user(s) to change password using the following sql command:
password
When change the password to a new one, please take note of the following:
New password could not be the same as user name, and could not be as simple as the following wording: "welcome, database, account, user, password, oracle, computer, abcd" and check if it contains at leat one letter and one numeric digit, and also it needs to be different from the previous one.
======================================================" > user_pass_expire.log
sqlplus -s /nolog <<EOF >> user_pass_expire.log
connect $USERID2
select username, expiry_date    
from dba_users 
where expiry_date-sysdate < 14
and expiry_date-sysdate > 0;
exit
EOF
mailx -s 'User Database Account Expire Soon in PROD' $MAIL_USER3 < user_pass_expire.log
fi
trap 'rm temp$$' 0 2 3 15
# end-of-script
