#!/usr/bin/ksh
#
#      Filename:  long_workflow_background_process.sh
#
#      Description:  Automatic monitoring of the PROD application
#                    to see if any of two requests of 
#                    Workflow Background Process running over 2 hours   
#
# #======================================================================
#
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi
sqlplus -s /nolog <<EOF > long_wkf_bgp.log 
connect $USERID2     
set head off
SELECT COUNT(*)
FROM APPS.FND_CONCURRENT_PROGRAMS, APPS.FND_CONCURRENT_REQUESTS, APPS.FND_CONCURRENT_PROGRAMS_TL
WHERE FND_CONCURRENT_PROGRAMS.CONCURRENT_PROGRAM_ID = FND_CONCURRENT_REQUESTS.CONCURRENT_PROGRAM_ID
AND FND_CONCURRENT_PROGRAMS_TL.CONCURRENT_PROGRAM_ID=FND_CONCURRENT_PROGRAMS.CONCURRENT_PROGRAM_ID
AND FND_CONCURRENT_REQUESTS.STATUS_CODE='R'
AND FND_CONCURRENT_PROGRAMS_TL.LANGUAGE='US'
AND FND_CONCURRENT_PROGRAMS_TL.USER_CONCURRENT_PROGRAM_NAME='Workflow Background Process'
AND (SYSDATE - FND_CONCURRENT_REQUESTS.ACTUAL_START_DATE)*24 > 0.5;
exit
EOF
# Check if the number in long_wkf_bgp.log is greater than or equal to 2
if [`cat long_wkf_bgp.log` -gt 1 ]
then 
echo "We DBAs need to cancel those stuck Workflow Background Process in Oracle Applications.">> long_running_workflow_bgp.log
mailx -s 'Issue of Workflow Background Process' $MAIL_USER0 < long_wkf_bgp.log 
fi
# end-of-script
#
