#!/bin/ksh
# script px_cleanup_tables.sh, for regularly cleaning up specified tables
# script cleanup_px_tables.sh (used to be cleanup_px_schedule_date_alert.sh)
# For cleaning up the PAXAR.PX_SCHEDULE_DATE_ALERT table. Run weekly for PX Schedule Date Change alerts performance
# The DELETE statement had been agreed by Greg Madden on Dec 8, 2006 
# Script created by EW, Dec 12, 2006
# Added "Delete from paxar.PX_FND_CONC_REQ_HISTORY ..." to the initial script cleanup_px_schedule_date_alert.sh 
# and renamed it to cleanup_px_tables.sh 	by EW, Jan 16, 2009
# added 6 more tables to the cleanup list based on communications with Paul Longtin, and re-worked the cleanup_px_tables.sh
# script. Renamed it to px_cleanup_tables.sh as the tables are not all owned by PAXAR schema 	By EW, May 4, 2010
# Note that the "alter table ... move;" lines can be uncommented if reorganizing the tables is desired.
# Commented out the "alter table ... move;" and the "alter index... rebuild online;" lines for the CLR objects as those operations 
# locked up CLR sessions. Need to shut down ClearOrbit application before running these ALTER statements  By EW, May 12, 2010
# added DELETE FROM SYS.AUD$ section to control SYS.AUD$ growth, may change ntimestamp# value as needed. By EW, August 24, 2010
# added as part of ADIM#1128004 for paxar schema delete jobs-- by Shiva,11/11/2013
# added as part of ADIM#1172934 for ultra user schema delet jobs -- by Shiva 12/10/2013
# added "Monitoring recyclebin size" section to alert the DBAs. By EW, September 01, 2010
# added index rebuild for JAVALIN.SHPHEADER_SID_UNIQUE and javalin.PACKAGES_CONSOL. by prasannar, 06/08/2020
###################################################################################################

echo " "
date
. /home/oraprod/work/all_PROD.env

sqlplus -s $USERID2  <<EOF 
set echo on feed on pages 50 lines 130
col segment_name for a35
col owner for a20
select segment_name, owner, bytes, extents, initial_extent, next_extent from dba_segments
where segment_name in ('PX_SCHEDULE_DATE_ALERT', 'PX_FND_CONC_REQ_HISTORY','BTA_TRANSACTIONS','BTA_STATUS',
'BP_LABEL_TRANSACTIONS', 'KEWILL_SHIPPING_INT', 'KEWILL_SHIPMENT_HEADER', 'PACKAGES' , 'AUD$') and segment_type = 'TABLE';

prompt Delete date older than 2 weeks from PAXAR.PX_SCHEDULE_DATE_ALERT ...
delete from PAXAR.PX_SCHEDULE_DATE_ALERT WHERE RUN_DATE < SYSDATE - 14;
select 'Rows remaining: '||count(*) from PAXAR.PX_SCHEDULE_DATE_ALERT;
commit;
-- alter table PAXAR.PX_SCHEDULE_DATE_ALERT move;
alter index paxar.PX_SCHEDULE_DATE_ALERT_N1 rebuild online;
alter index paxar.PX_SCHEDULE_DATE_ALERT_N2 rebuild online;
-- gather stats after the above changes in data
exec fnd_stats.gather_table_stats (ownname => 'PAXAR', tabname => 'PX_SCHEDULE_DATE_ALERT', cascade => TRUE);
prompt 

prompt DELETE data older than 60 days from paxar.PX_FND_CONC_REQ_HISTORY...
rem delete from paxar.PX_FND_CONC_REQ_HISTORY where actual_completion_date  < sysdate - 60;
delete from paxar.PX_FND_CONC_REQ_HISTORY where last_update_date  < sysdate - 60;
select 'Rows remaining: '||count(*) from PAXAR.PX_FND_CONC_REQ_HISTORY where last_update_date  < sysdate;
commit;
-- alter table paxar.PX_FND_CONC_REQ_HISTORY move;
alter index paxar.PX_FND_CONC_REQ_HISTORY_C1 rebuild online;
exec fnd_stats.gather_table_stats (ownname => 'PAXAR', tabname => 'PX_FND_CONC_REQ_HISTORY', cascade => TRUE);
prompt

prompt DELETE data older than 60 days from error message table PAXAR.PX_MACLINK_XFR_ERR
DELETE  PAXAR.PX_MACLINK_XFR_ERR where  creation_date<sysdate-60;

-- the following 6 DELETE statements for cleaning up CLR, KEWILL, and JAVALIN tables were from Paul Longtin, May 3, 2010
prompt DELETE data older than 60 days from clr.bta_transactions...
DELETE FROM clr.bta_transactions WHERE creation_date < SYSDATE - 60;
select 'Rows remaining: '||count(*) from clr.bta_transactions;
commit;
-- alter table clr.bta_transactions move;
exec fnd_stats.gather_table_stats (ownname => 'CLR', tabname =>'BTA_TRANSACTIONS');
prompt  

prompt DELETE finished transactions from CLR.BTA_STATUS table...
DELETE FROM clr.bta_status WHERE transaction_id NOT IN (SELECT transaction_id FROM clr.bta_transactions);
select 'Rows remaining: '||count(*) from clr.BTA_STATUS;
commit;
-- alter table CLR.BTA_STATUS move;
exec fnd_stats.gather_table_stats (ownname => 'CLR', tabname =>'BTA_STATUS');
prompt

prompt DELETE data older than 30 days from clr.bp_label_transctions...
DELETE FROM clr.bp_label_transactions WHERE creation_date < SYSDATE - 30;
select 'Rows remaining: '||count(*) from clr.bp_label_transactions;
commit;
-- alter table clr.bp_label_transactions move;
-- alter index clr.BP_LABEL_TRANSACTIONS_N1 rebuild online;
-- alter index clr.BP_LABEL_TRANSACTIONS_U1 rebuild online;
exec fnd_stats.gather_table_stats (ownname => 'CLR', tabname =>'BP_LABEL_TRANSACTIONS', cascade => TRUE);
prompt 

prompt DELETE data older than 1 year from kewill.kewill_shipping_int...
DELETE FROM kewill.kewill_shipping_int WHERE creation_date < SYSDATE - 365 ;
select 'Rows remaining: '||count(*) from kewill.kewill_shipping_int;
commit;
alter table kewill.kewill_shipping_int move;
exec fnd_stats.gather_table_stats (ownname => 'KEWILL', tabname =>'KEWILL_SHIPPING_INT');
prompt

prompt DELETE data older than 1 year from javalin.shipment_header ... 
DELETE FROM javalin.shipment_header WHERE ship_date < TO_CHAR(SYSDATE - 365,'YYYY-MM-DD');
select 'Rows remaining: '||count(*) from javalin.shipment_header;
commit;
alter table javalin.shipment_header move;
-- indexes had changed after Javalin upgrade in late March 2011
alter index JAVALIN.SHPHEADER_SID_UNIQUE rebuild online;
alter index javalin.SHPHEADER_CLOSE_IDX rebuild online;
alter index javalin.SHPHEADER_DC rebuild online;
alter index javalin.SHPHEADER_IDX1 rebuild online;
alter index javalin.SHPHEADER_IDX2 rebuild online;
alter index javalin.SHPHEADER_IDX3 rebuild online;
alter index javalin.SHPHEADER_UPLOAD_IDX rebuild online;
exec fnd_stats.gather_table_stats (ownname => 'JAVALIN', tabname =>'SHIPMENT_HEADER', cascade => TRUE);
prompt

prompt DELETE data from javalin.PACKAGES that is not in SHIPMENT_HEADER...
DELETE FROM javalin.packages WHERE ship_date < TO_CHAR(SYSDATE - 365,'YYYY-MM-DD') and ship_date NOT IN (SELECT ship_date FROM javalin.shipment_header);
select 'Rows remaining: '||count(*) from javalin.PACKAGES;
commit;
alter table javalin.PACKAGES move;
alter index javalin.PACKAGES_CONSOL rebuild online;
-- indexes had changed after Javalin upgrade in late March 2011
alter index javalin.PACKAGES_IDX rebuild online;
alter index javalin.SYS_C005452643 rebuild online;
exec fnd_stats.gather_table_stats (ownname => 'JAVALIN', tabname =>'PACKAGES', cascade => TRUE);

prompt DELETE data from SYS.AUD$ where ntimestamp# < sysdate - 7...
connect / as sysdba
DELETE from SYS.AUD$ where ntimestamp# < sysdate - 7;
commit;
-- may manually alter index after a table truncation or when the table is small
-- alter index sys.I_AUD1 rebuild online;

prompt DELETE data from PAXAR  schema tables
delete from paxar.px_ultra_shipments where last_update_date < sysdate - 4;
delete from paxar.px_ultra_temp_deliveries where creation_date < sysdate - 4;
delete from paxar.px_ultra_carton_headers where delivery_id not in (select delivery_id from paxar.px_ultra_temp_deliveries);
delete from paxar.px_ultra_carton_details where carton_id not in (select carton_id from paxar.px_ultra_carton_headers);
commit;

prompt Delete data from ULTRAUSR schema tables
delete from 
ultrausr.px_ultra_trxns_djc 
where trxn_id in (select dj.trxn_id from ultrausr.px_ultra_trxns_hdr hr inner join 
ultrausr.px_ultra_trxns_djc dj on dj.trxn_id = hr.trxn_id where hr.trxn_date < sysdate - 30);
delete from 
ultrausr.px_ultra_trxns_subinv 
where trxn_id in (select si.trxn_id from
ultrausr.px_ultra_trxns_hdr hr inner join 
ultrausr.px_ultra_trxns_subinv si on si.trxn_id = hr.trxn_id 
where hr.trxn_date < sysdate - 30);
delete from 
ultrausr.px_ultra_trxns_wip 
where trxn_id in (select wi.trxn_id from
ultrausr.px_ultra_trxns_hdr hr inner join 
ultrausr.px_ultra_trxns_wip wi on wi.trxn_id = hr.trxn_id 
where hr.trxn_date < sysdate - 30);
delete from 
ultrausr.px_ultra_trxns_hdr 
where trxn_date < sysdate - 30;
commit;

select segment_name, owner, bytes, extents, initial_extent, next_extent from dba_segments
where segment_name in ('PX_SCHEDULE_DATE_ALERT', 'PX_FND_CONC_REQ_HISTORY','BTA_TRANSACTIONS','BTA_STATUS',
'BP_LABEL_TRANSACTIONS', 'KEWILL_SHIPPING_INT', 'KEWILL_SHIPMENT_HEADER', 'PACKAGES', 'AUD$' ) and segment_type = 'TABLE';

exit
EOF

#  Monitoring recyclebin sizes:
sqlplus -s "/ as sysdba" << EOF |mail -s "Recyclebin Size by Tablespace in PROD" eric.wang@averydennison.com
col TotalBytes for 99,999,999,999
col tablespace_name for a18
set echo on feed on pages 50 lines 130
 select tablespace_name, sum(bytes) "TotalBytes" , count(*) "# of Objects" from dba_segments where segment_name like 'BIN$%' 
group by tablespace_name order by sum(bytes) desc;
exit
EOF

# End of script
