
# temporary fix for an allocation problem as per Paul Thomas, 11/8/02

# export ORACLE_HOME
# ORACLE_SID=PROD; export ORACLE_SID
# ORAENV_PATH=/usr/local/bin; export ORAENV_PATH
# PATH=$PATH:$ORAENV_PATH; export PATH
# ORAENV_ASK=NO; export ORAENV_ASK
# . $ORAENV_PATH/oraenv 2>/dev/null
. /u01/oracle/proddb/9.2.0/PROD_pxrdb2.env
sqlplus -s apps/mysox222@PROD <<EOF
delete from mtl_material_transactions_temp 
 where transaction_temp_id in 
 (select transaction_temp_id from (
select mmt.organization_id, transaction_temp_id, mmt.creation_date, segment1, 
subinventory_code,  transaction_quantity, order_number, line_number, ool.flow_status_code 
 from  mtl_material_transactions_temp mmt, 
       mtl_system_items_b msi, 
	   oe_order_headers_all ooh, 
	   oe_order_lines_all ool 
where mmt.transaction_type_id = 52 -- sales orderpick
  and msi.inventory_item_id = mmt.inventory_item_id 
  and msi.organization_id = mmt.organization_id 
  and mmt.trx_source_line_id = ool.line_id 
  and ool.header_id = ooh.header_id 
  and  ((select line_id from mtl_txn_request_lines where line_id = mmt.move_order_line_id) is null  -- discon. 
   or   (select line_status from mtl_txn_request_lines where line_id = mmt.move_order_line_id) = 9)  --canc by source
   order by mmt.organization_id, mmt.creation_date
      ) duds )
/  
commit
/
exit
EOF

