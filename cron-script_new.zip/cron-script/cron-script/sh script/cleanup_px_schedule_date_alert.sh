#!/bin/ksh
# For cleaning up the PAXAR.PX_SCHEDULE_DATE_ALERT table. Run weekly for PX Schedule Date Change alerts performance
# The DELETE statement had been agreed by Greg Madden on Dec 8, 2006 
# Script created by EW, Dec 12, 2006
echo "DELETE FROM PAXAR.PX_SCHEDULE_DATE_ALERT ..."
date
. /home/oraprod/work/all_PROD.env
sqlplus -s $USERID2  <<EOF 
delete from PAXAR.PX_SCHEDULE_DATE_ALERT WHERE RUN_DATE < SYSDATE - 14;
select 'Rows remaining: '||count(*) from PAXAR.PX_SCHEDULE_DATE_ALERT;
commit;
-- gather stats after the above changes in data
exec fnd_stats.gather_table_stats (ownname => 'PAXAR', tabname => 'PX_SCHEDULE_DATE_ALERT');
exit
EOF
