#!/usr/bin/ksh
DAY=`date '+%d'`
MONTH=`date '+%b'`
YEAR=`date '+%Y'`
RMDATE=`date +'%b%d-%Y-%T-%z'`
export ORACLE_SID=PROD
export MAIL_LIST="gdc.dba.group@averydennison.com, oracle_dbas@averydennison.com"
LOG='/home/oraprod/TCS/backup/rman/log_destn_change.log'
# #Define env variables
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi


## Calculating current threshold
##
## Get current archive destination
ARCH_DEST=`sqlplus -s $USERID1 << EOF
set head off feed off pagesize 0
select value from v\\$parameter where name = 'log_archive_dest';
EOF
`

## Get current threshold value
df -k `echo $ARCH_DEST |cut -c 1-4` |grep -v Used|awk '{ print $4 }'|read ARCHFSPCT



##
## Check threshhold levels and see if maintenance needs to occur
##

if [[ $ARCHFSPCT > 95% ]]
then echo "archive destination is $ARCH_STATUS full please contact DBA"
echo "archive destination /u17 is full on paxar." | mailx -s "archive destination on paxar is $ARCHFSPCT full.Changing the destination" $LOG
cat $LOG | mailx -s "changing archive destn on pxrdb2" $MAIL_LIST
sqlplus /nolog << EOF
set echo on
connect / as sysdba
ALTER SYSTEM SET log_archive_dest ='/u33/oracle/arch/PROD' scope=memory; 
exit;
EOF
fi

exit
