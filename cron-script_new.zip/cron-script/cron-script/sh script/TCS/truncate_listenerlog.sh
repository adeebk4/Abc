#!/bin/ksh
cd /d01/oracle/proddb/diag/tnslsnr/pxrdb2/prod/trace
cp prod.log /d01/oracle/proddb/diag/tnslsnr/pxrdb2/prod/trace/prod_`date '+%Y%m%d%H%M%S'`.log
echo > prod.log
