#!/bin/ksh

export ORACLE_SID=PROD
NLS_DATE_FORMAT='DD-MON-YYYY HH24:MI:SS'
DAY=`date '+%d'`
MONTH=`date '+%b'`
YEAR=`date '+%Y'`
RMDATE=`date +'%b%d-%Y-%T-%z'`
LOG="/home/oraprod/TCS"
DLOG="$LOG/rman_delete_eom.log"

#List month end backups

rman log $DLOG append << EOF
 connect target /
 connect catalog PRODCAT/PRODCTLG@rcat11
 list backup summary tag 'DB MONTH END FULL BACKUP';
EOF
