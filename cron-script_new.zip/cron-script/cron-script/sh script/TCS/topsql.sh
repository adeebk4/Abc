. ~/.profile
export ORAENV_ASK=NO
export LOGFILE=/home/oraprod/TCS/topsqltest.out
export SQLFILE=/home/oraprod/TCS/topsql.sql
#export CONFIG_FILE=/home/oraprod/TCS/database_tasks.tab
#export SIDLIST=`cat $CONFIG_FILE|grep "TOPSQL=Y"|cut -d "|" -f 1`


for SID in $SIDLIST
do
        export ORACLE_SID=$SID
        . oraenv

        sqlplus -s /nolog <<EOF!
        connect / as sysdba
        WHENEVER SQLERROR EXIT FAILURE
        set term off
        set echo off
        set feedback off
        set serveroutput off
        set pagesize 200
        set linesize 200
        SET MARKUP HTML ON SPOOL ON
        spool $LOGFILE
        @$SQLFILE
        spool off
EOF!


        export MAILTO="sharath.kumarms@averydennison.com"
        export CONTENT=$LOGFILE
        export SUBJECT="REPORT: TOP 5 SQL STATEMENTS OF DATABASE $SID"
        (
        echo "Subject: $SUBJECT"
        echo "MIME-Version: 1.0"
        echo "Content-Type: text/html"
        echo "Content-Disposition: inline"
        cat $CONTENT
        ) | /usr/sbin/sendmail $MAILTO

done

