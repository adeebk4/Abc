#!/bin/ksh
ORACLE_SID=PROD
export ORACLE_SID
ORACLE_HOME=/d01/oracle/proddb/12.1.0.2/
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH


$ORACLE_HOME/bin/sqlplus "/ as sysdba" <<EOF > /home/oraprod/TCS/TBS.log
SET ECHO OFF
set pages 1000
set feedback off
SET MARKUP HTML ON SPOOL ON
SPOOL TBS.html 
select tablespace_name, free_percent, free_size_mb
from (
            SELECT b.tablespace_name, b.tablespace_size_mb, sum(nvl(fs.bytes,0))/1024/1024 free_size_mb,
            (sum(nvl(fs.bytes,0))/1024/1024/b.tablespace_size_mb *100) free_percent
            FROM dba_free_space fs,
                 (SELECT tablespace_name, sum(bytes)/1024/1024 tablespace_size_mb FROM dba_data_files
                  GROUP BY tablespace_name
                 ) b
           where fs.tablespace_name = b.tablespace_name
           group by b.tablespace_name, b.tablespace_size_mb
        ) ts_free_percent
WHERE free_percent < 15 
ORDER BY free_percent;
spool off
exit
EOF
export MAILTO="gdc.dba.group@averydennison.com","shiva.prasad@averydennison.com","roger.feng@ap.averydennison.com","prasanna.ramanujam@ap.averydennison.com","tanmayee.patro@ap.averydennison.com","muralidharreddy.mallu@ap.averydennison.com"
export CONTENT="/home/oraprod/TBS.html"
export SUBJECT="TABLESPACE FREESPACE REPORT"
(
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat $CONTENT
) | /usr/sbin/sendmail $MAILTO




