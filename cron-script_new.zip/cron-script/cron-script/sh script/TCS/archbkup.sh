#!/usr/bin/ksh
## =============================================================================
## Script to backup/transfer the archive logs to NIM server
##
##
##
##==============================================================================
## Declare variables
export SCRIPTS=/home/oraprod/TCS/backup/scripts
export ORACLE_SID=$1
export OTAB=/etc/oratab
export ATAB=$SCRIPTS/archtab                    #Archive file destination details
export LOG=$SCRIPTS/log/$ORACLE_SID.log         #Log file
export HNAME=`hostname`                         #Get hostname
export THNAME=10.12.36.89                       #FTP NIM server credetials with .netrc file
export THDIR=/archivelogs/oracle/                #FTP home directory
export TFILE=$SCRIPTS/tfile.txt

> $TFILE

echo "---------------`date`---------------" >> $LOG
echo $#

if [ $# -eq 0 ]
then
 echo "Usage: Scriptname DBNAME [Minutes]" >> $LOG
 exit
fi


if [ -z echo `grep $1 $OTAB` ]
then
  echo "DBNAME not found" >> $LOG
  exit
fi

if [ $2 > 60 ]
then
   MINS=$2
   echo "Setting no of minutes to $2 " >> $LOG
else
   MINS=60  # default value
fi

cat $ATAB | grep $ORACLE_SID | while read LINE; 
do
  case "$LINE" in 

  \#*) continue ;; 

  *) export ADEST=`echo $LINE | cut -f 2 -d :`
     find $ADEST -type f -cmin -$MINS >> $TFILE
  esac
 
done 

export TDIR=$THDIR/$HNAME/$ORACLE_SID

cat $TFILE | while read LINE
do
   FNAME=`basename $LINE`
   echo "put $LINE $TDIR/$FNAME"
done | ftp 10.12.36.89 >> $LOG

echo "FTPed all the files" >> $LOG

tail -6 $LOG | mailx -s "stpdadc76:backup-transfer the archive logs" gdc.dba.group@averydennison.com
