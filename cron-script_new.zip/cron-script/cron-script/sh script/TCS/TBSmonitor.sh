#!/bin/ksh
ORACLE_SID=PROD
export ORACLE_SID
ORACLE_HOME=/d01/oracle/proddb/12.1.0.2/
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH


$ORACLE_HOME/bin/sqlplus "/ as sysdba" <<EOF >/home/oraprod/TCS/tablespace_monitor.log
SELECT /* + RULE */  df.tablespace_name "Tablespace",
       df.bytes / (1024 * 1024 * 1024) "Size (GB)",
       SUM(fs.bytes) / (1024 * 1024 * 1024) "Free (GB)",
       Nvl(Round(SUM(fs.bytes) * 100 / df.bytes),1) "% Free",
       Round((df.bytes - SUM(fs.bytes)) * 100 / df.bytes) "% Used"
  FROM dba_free_space fs,
       (SELECT tablespace_name,SUM(bytes) bytes
          FROM dba_data_files where tablespace_name in('APPS_TS_INTERFACE','APPS_TS_ARCHIVE','APPS_TS_TOOLS','APPS_TS_TX_DATA','APPS_TS_SEED','APPS_TS_SUMMARY','APPS_TS_QUEUES','APPS_TS_MEDIA','APPS_TS_TX_IDX','APPS_TS_NOLOGGING')
         GROUP BY tablespace_name) df
 WHERE fs.tablespace_name (+)  = df.tablespace_name
 GROUP BY df.tablespace_name,df.bytes;
exit
EOF
if [ `cat /home/oraprod/TCS/tablespace_monitor.log | wc -l` -gt 0 ]
then
   cat /home/oraprod/TCS/tablespace_monitor.log | mailx -s 'Alert: Tablespace utilization report' "gdc.dba.group@averydennison.com" ,"Oracle_SCM@ap.averydennison.com","oracle_dbas@averydennison.com","merlin.rajesh@ap.averydennison.com","waynee.wang@ap.averydennison.com","tanmayee.patro@ap.averydennison.com","muralidharreddy.mallu@ap.averydennison.com"

fi

