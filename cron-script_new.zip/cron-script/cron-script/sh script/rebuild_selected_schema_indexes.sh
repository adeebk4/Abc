

USERID=system/chisox23; export USERID

# the working directory
if [ -s `dirname $0` ] ; then
DIR=`dirname $0`
else
DIR=`pwd`
fi
export DIR

ORACLE_HOME=/u01/oracle/proddb/9.2.0
export ORACLE_HOME
ORACLE_SID=PROD; export ORACLE_SID
ORAENV_PATH=/usr/local/bin; export ORAENV_PATH
PATH=$PATH:$ORAENV_PATH; export PATH
ORAENV_ASK=NO; export ORAENV_ASK
. $ORAENV_PATH/oraenv 2>/dev/null

RECORD=$DIR/rebuild_all_indexes.dat; export RECORD
if [ ! -s $RECORD ] ; then
touch $RECORD
fi

cat <<EOF >$DIR/gen_rebuild_sel_indexes.sql
set echo off
set feedback off
set ver off
set heading off
set pagesize 4000
select 'set timing on' from dual;
select 'set echo on' from dual;
REM select 'spool rebuild_all_indexes.log'  from dual;
select 'alter index ' || owner || '.' || index_name || ' rebuild online ;'
from dba_indexes
-- where owner not in ('SYS','SYSTEM', 'MDSYS','CTXSYS', 'ORDSYS','PRECISE','VRTSI3PW')
where owner in ('INV','BOM','APPLSYS')
order by owner;
select 'exit' from dual;
REM spool off
exit
EOF

# generate rebuild_sel_indexes.sql
sqlplus -s $USERID @$DIR/gen_rebuild_sel_indexes.sql > $DIR/rebuild_sel_indexes.sql

sqlplus -s /nolog <<EOF >>$DIR/rebuild_sel_indexes.log
set echo on feed on
conn $USERID 
@$DIR/rebuild_sel_indexes.sql
exit
EOF

if [ $? -eq 0 ]; then
echo "Indexes in selected schemas have been rebuilt on this date:" >> $RECORD
else
echo "Index reuilding failed on this date:" >> $RECORD
fi
date >> $RECORD

