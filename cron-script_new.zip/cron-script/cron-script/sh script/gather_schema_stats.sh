
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi
sqlplus -s $USERID1 @/home/oraprod/admin/gather_schema_stats.sql
