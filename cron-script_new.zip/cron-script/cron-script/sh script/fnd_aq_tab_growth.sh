#!/usr/bin/ksh
#
#      Filename:  fnd_aq_tab_growth.sh
#
#      Description:  This script checks the count of FND AQ tables weekly and sends mail to DBAs
#                                        
# #====================================================================================================
#
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi

sqlplus -s /nolog <<EOF > fnd_aq_tab_growth.log
connect $USERID2
set pagesize 0 feedback off verify off heading off echo off;
@/home/oraprod/scripts/fnd_aq_tab_growth.sql;
exit
EOF

cat fnd_aq_tab_growth.log | mailx -s 'PROD: COUNT ON FND AQ TABLES' $MAIL_USER1 
date >> fnd_aq_tab_growth.log
cat fnd_aq_tab_growth.log >> /home/oraprod/work/log/fnd_aq_tab_growth_history.log
rm fnd_aq_tab_growth.log
