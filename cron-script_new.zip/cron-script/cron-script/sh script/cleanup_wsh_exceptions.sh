#!/bin/ksh
# For cleaning up the WSH_EXCEPTIONS table. Run every night. 9/02
echo "DELETE FROM WSH_EXCEPTIONS ..."
date
. /home/oraprod/work/all_PROD.env
sqlplus -s $USERID2  <<EOF 
delete from wsh.wsh_exceptions where status in ('NO_ACTION_REQUIRED', 'CLOSED');
select 'Rows remaining: '||count(*) from wsh_exceptions;
commit;
-- gather stats after the above changes in data
exec fnd_stats.gather_table_stats (ownname => 'WSH', tabname => 'WSH_EXCEPTIONS');
exit
EOF
