#!/bin/sh
#####################################################################
###   START OF UNIX SCRIPT                                        ###
#####################################################################

## Define env variables
if [ -f /home/oraprod/work/all_PROD.env ] ; then
        . /home/oraprod/work/all_PROD.env
else
        echo "all_PROD.env parameter file does not exist, exiting script execution."
        exit
fi

#
cd /home/oraprod/work/log
LOG_FILE="gs_om_tables.log"
(
     echo "Collecting Stats...."
     date
     sqlplus -s $USERID2 @/home/oraprod/scripts/gtsom.sql
     echo "Done"
     date
) | tee $LOG_FILE     

export MAILTO="oracle_dbas@averydennison.com"
#export MAILTO="roger.feng@ap.averydennison.com"
export CONTENT="/home/oraprod/scripts/UL.html"
export SUBJECT="PROD Table Statistics"
(
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat $CONTENT
) | /usr/sbin/sendmail $MAILTO


#
#####################################################################
###   END OF UNIX SCRIPT                                          ###
#####################################################################

