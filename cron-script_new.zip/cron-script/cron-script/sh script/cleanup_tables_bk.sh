#!/usr/bin/ksh
#################################################
# Usage: cleanup_tables.sh [DaysToKeep :=90]
# Script for automating data purges in selected tables
# currently it purges:
# 1) GL_INTERFACE_HISTORY, 90 days or older
# 2) MTL_TXT_REQUEST_LINES, 90 days or older
# By EWANG, 7/2004
# Changed to run purge_mo_new1_90.sql, 8/2005
#################################################

MAIL_USER="eric.wang@paxar.com"

DIR=`dirname $0`
if [ -z $DIR ] ; then
DIR=`pwd`
fi
export DIR
export LOG_FILE=$DIR/log/cleanup_tables_`date +%m%d%y`.log
if [ ! -f $LOG_FILE ] ; then
touch $LOG_FILE
fi
date >>$LOG_FILE

# Oracle server code and env variables
. /home/oraprod/work/all_PROD.env

# validate parameter
if [ $1 ] ; then
        if [ $1 -ge 90 ] ; then
                echo "Deleting from target tables for data older than $1 days">>$LOG_FILE
                DaysToKeep=$1
        else
                echo "The DaysToKeep parameter you specified was not a valid number or was less than 90" >>$LOG_FILE
                echo "Exiting...">>$LOG_FILE
                exit
        fi
else
        echo "You have not specified DaysToKeep value for the cleanup.">>$LOG_FILE
        echo "Please indicate if you want to proceed with the default 90. Y/[N]">>$LOG_FILE
        read temp
        temp=${temp:-"n"}
	echo "You entered $temp" >>$LOG_FILE
        case $temp in
                Y|y) DaysToKeep=90
                ;;
                *) echo "Exiting the cleanup..." >>$LOG_FILE
                   exit
                ;;
        esac
fi

sqlplus -s $USERID2 << EOF >>$LOG_FILE
Set pages 50 lines 130 head on echo on feed on
prompt
prompt ****************************************************
 prompt -- Purging GL_INTERFACE_HISTORY
 prompt -- Rows before the purge:
 select count(*) from gl.GL_INTERFACE_HISTORY;
 prompt -- Purging...
 delete from gl.gl_interface_history 
 where Date_created < sysdate - $DaysToKeep and status = 'PROCESSED';
 commit;
 prompt -- Rows after the purge:
 select count(*) from gl.GL_INTERFACE_HISTORY;
 prompt -- Gather table stats
 exec fnd_stats.gather_table_stats (ownname => 'GL',tabname =>'GL_INTERFACE_HISTORY',cascade => TRUE);
 prompt -- Done with GL_INTERFACE_HISTORY
-- INV.MTL_TXN_REQUEST tables
prompt ****************************************************
prompt -- Purging MTL_TXN_REQUEST_LINES and MTL_TXN_REQUEST_HEADERS
prompt -- Before the purge:
prompt -- Segments
col segment_name for a30
col segment_type for a16
select segment_name, segment_type, bytes, extents , next_extent from
dba_segments where segment_name like 'MTL_TXN_REQUEST_%' and owner = 'INV';

prompt -- Rows
select count(*) from INV.MTL_TXN_REQUEST_LINES;
select count(*) from INV.MTL_TXN_REQUEST_HEADERS;

prompt -- Tablespace sizes
select tablespace_name, sum(bytes) from dba_data_files where tablespace_name like 'INV%' group by tablespace_name;
prompt -- Free space
Select tablespace_name, sum(bytes) from dba_free_space where tablespace_name like 'INV%' group by tablespace_name;
 
prompt -- Purging...
start /home/oraprod/admin/purge_mo_new1_90.sql
$DaysToKeep
Y
-- the script has been modified from purge_mo_new.sql for this purpose.
prompt -- After the purge:
select count(*) from INV.MTL_TXN_REQUEST_LINES;
select count(*) from INV.MTL_TXN_REQUEST_HEADERS;
exit
EOF

# Error checking
grep "ORA-" $LOG_FILE
if [ $(grep "ORA-" $LOG_FILE) ] ; then
	mail -s "Data Cleanup Job in $ORACLE_SID Returned and ORA- Error" $MAIL_USER
	exit
fi

# if no error, then rebuild indexes
# generate the rebuild script
sqlplus -s $USERID2 << EOF >$DIR/rebuild_index.sql
set head off echo off feed off pages 0
Select 'alter index inv.'||index_name||' rebuild online;' from dba_indexes 
Where table_name like 'MTL_TXN_REQUEST_%S' and table_owner='INV';
exit
EOF

sqlplus -s $USERID2 << EOF >>$LOG_FILE
set echo on lines 100
prompt -- rebuilding the indexes
start $DIR/rebuild_index.sql
prompt -- free space in INVX tablespace after index rebuild
select sum(bytes) from dba_free_space where tablespace_name = 'INVX';
prompt -- Segment sizes
col segment_name for a30
col segment_type for a16
col bytes for 99,999,999,999
select segment_name, segment_type, bytes, extents , next_extent from
dba_segments where segment_name like 'MTL_TXN_REQUEST_%' and owner = 'INV';
prompt -- gather stats
exec fnd_stats.gather_table_stats (ownname => 'INV',tabname =>'MTL_TXN_REQUEST_LINES',cascade => TRUE);
Exec fnd_stats.gather_table_stats (ownname => 'INV',tabname =>'MTL_TXN_REQUEST_HEADERS', cascade => TRUE);
exit
EOF

# Index rebuild error?
if [ $(egrep "ORA-01652|ORA-01658" $LOG_FILE) ] ; then
        mail -s "Error Rebuilding MTL_TXN_REQUEST indexes in INVX in $ORACLE_SID" $MAIL_USER
        exit
fi
# clean up
rm $DIR/rebuild_index.sql
echo "Finished at: " $(date) >>$LOG_FILE
