while true 
do
sqlplus -s apps/mysox222@PROD <<EOF >process.log
set echo off feed off
select sid, serial#, process, module from v\$session where sql_hash_value in
(select hash_value from v\$sqltext where sql_text like 'select ood . organization_code org , oot . name order_type%');
exit
EOF
if [ -s process.log ] ; then
	for P in `cat process.log` 
	do
	ps -ef|grep $P
	done
fi

sleep 60
done
