#!/usr/bin/ksh
################################################################################
# Usage lobsegment_space_alert.sh
# Certain actions in Oracle Applications like file attachment in Sales Orders 
# appear to fail due to lobsegment unable to extend space. 
# The DBA Oracle alerts do not monitor LOBSEGMENT segment type
# It does not appear to generate errors in the alert_SID.log file either.
# This script can be used to identify those segments and tablespaces
# and alert the $MAIL_USER
# EWang 4/26/2004
###############################################################################

## MAIL_USER='eric.wang@paxar.com david.fei@paxar.com fred.link@paxar.com'
MAIL_USER=eric.wang@paxar.com
APPS_CONN='apps/mysox222@PROD'

export DIR=`dirname $0`

. /u01/oracle/proddb/9.2.0/PROD_pxrdb2.env

# largest next_extent values in tablespaces
sqlplus -s $APPS_CONN <<EOF >$DIR/lob_extent.lst
set head off echo off feed off pages 0
select tablespace_name||':'|| max(next_extent) from dba_segments 
where segment_type='LOBSEGMENT' group by tablespace_name;
exit
EOF

for lob_ext in `cat $DIR/lob_extent.lst`
	do
		tbs=`echo $lob_ext|awk -F: '{ print  $1 }'`
		next_ex=`echo $lob_ext|awk -F: '{ print $2 }'`
		sqlplus -s $APPS_CONN <<EOF |read max_free
		set head off echo off feed off pages 0
		select max(bytes) from dba_free_space
		where tablespace_name = '$tbs' 
		group by tablespace_name;
		exit
EOF

   if [ $max_free -lt $next_ex ] ; then
	echo "The largest chunk of free space in $tbs is $max_free bytes." >$DIR/lob_alert.lst
	sqlplus -s $APPS_CONN <<EOF >>$DIR/lob_alert.lst
	col segment_name for a45
	prompt The offending segment:
	select segment_name, next_extent from dba_segments a
	where tablespace_name = '$tbs' and next_extent =
	(select max(next_extent) from dba_segments
	where tablespace_name = '$tbs'
	group by tablespace_name);
	exit
EOF

	cat $DIR/lob_alert.lst|mail -s "Alert: Tablespace $tbs Has Insufficient Space" $MAIL_USER
   fi
done

return 0	
