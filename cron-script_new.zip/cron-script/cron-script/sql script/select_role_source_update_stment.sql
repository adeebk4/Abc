
grant execute on APPS.AD_TUMS to select_role;
grant execute on APPS.AD_TUMS to select_role;
grant execute on APPS.CRM_TUMS to select_role;
grant execute on APPS.CRM_TUMS to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123063033 to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123063033 to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123063127 to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123063127 to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123110523 to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123110523 to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123151121 to select_role;
grant execute on APPS.EUL5_BATCH_PACKAGE200123151121 to select_role;
grant execute on APPS.FIN_TUMS to select_role;

grant execute on APPS.FIN_TUMS to select_role;
grant execute on APPS.FND_TUMS to select_role;
grant execute on APPS.FND_TUMS to select_role;
grant execute on APPS.HR_TUMS to select_role;
grant execute on APPS.HR_TUMS to select_role;
grant execute on APPS.MFG_TUMS to select_role;
grant execute on APPS.MFG_TUMS to select_role;
grant execute on APPS.PA_TUMS to select_role;
grant execute on APPS.PA_TUMS to select_role;
