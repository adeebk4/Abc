set echo on feed on
select count(*) from CST_LOW_LEVEL_CODES;
select count(*) from         CST_STD_COST_ADJ_TEMP;
select count(*) from         BOM_LISTS;
select count(*) from         CST_ROLLUP_DELETE_TEMP;
select count(*) from         BOM_SMALL_EXPL_TEMP;
select count(*) from         CST_LISTS;
select count(*) from         BOM_EXPLOSION_TEMP;
select count(*) from         CST_EXPLOSION_TEMP;
