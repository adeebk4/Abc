select event, count(*) "Num of Waits" from v$session_wait group by event order by count(*);
