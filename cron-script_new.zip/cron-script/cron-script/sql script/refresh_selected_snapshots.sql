set echo on
Alter session set events '1031 trace name errorstack level 3';
 select MRP_AP_REFRESH_S.NEXTVAL from dual;
	-- to avoid "ORA-08002: sequence MRP_AP_REFRESH_S.CURRVAL is not yet defined in this session" error
 exec dbms_snapshot.refresh ('"APPS"."MRP_FORECAST_DATES_SN"', 'F')
 exec dbms_snapshot.refresh ('"APPS"."MTL_SYS_ITEMS_SN"', 'F')
 exec dbms_snapshot.refresh ('"APPS"."MTL_DEMAND_SN"', 'F')
 exec dbms_snapshot.refresh ('"APPS"."MTL_ITEM_CATS_SN"', 'F')
 exec dbms_snapshot.refresh ('"APPS"."OE_ODR_LINES_SN"', 'F')
 exec dbms_snapshot.refresh ('"APPS"."WIP_WOPRS_SN"', 'F')

select MVIEW_NAME, owner, REFRESH_METHOD, to_char(last_refresh_date, 'yyyy-mm-dd HH24:MI:SS') Last_Fresh_Time
from dba_mviews where mview_name in ('MRP_FORECAST_DATES_SN', 'MTL_SYS_ITEMS_SN', 'MTL_DEMAND_SN', 
'MTL_ITEM_CATS_SN', 'OE_ODR_LINES_SN', 'WIP_WOPRS_SN')
Order by last_refresh_date;

