col user_name for a25
col user_concurrent_program_name for a35 trunc
set  pages 50 lines 130
col oracle_spid for a11
col os_id for a10
Select user_name, request_id, user_concurrent_program_name,
(sysdate - actual_start_date)*24*3600 Duration
, phase_code, status_code, oracle_process_id Oracle_SPid, os_process_id OS_Id, d.sid SID
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c, v$session d
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and a.program_application_id=c.application_id
and c.language = 'US'
and a.os_process_id=d.process(+)
And  phase_code='R' and status_code='R'
order by 3
/
