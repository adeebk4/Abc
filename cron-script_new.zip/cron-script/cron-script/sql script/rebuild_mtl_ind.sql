set echo on
alter index inv.MTL_TXN_REQUEST_LINES_N2 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_U1 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_U2 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_N5 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_N1 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_N6 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_N3 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_N4 rebuild online;                        
alter index inv.MTL_TXN_REQUEST_LINES_C1 rebuild online;                        

