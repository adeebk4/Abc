set pages 0 verify off feed off
# col module for a12
select osuser from v$process a, v$session b
where a.addr=b.paddr
and spid=&1
/
