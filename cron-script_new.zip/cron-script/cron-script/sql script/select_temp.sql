prompt select count(*) from BOM.CST_ROLLUP_DELETE_TEMP;
select count(*) from BOM.CST_ROLLUP_DELETE_TEMP;
prompt select count(*) from BOM.CST_LOW_LEVEL_CODES;
select count(*) from BOM.CST_LOW_LEVEL_CODES;
prompt select count(*) from BOM.CST_STD_COST_ADJ_TEMP;
select count(*) from BOM.CST_STD_COST_ADJ_TEMP;
prompt select count(*) from BOM.BOM_EXPLOSION_TEMP;
select count(*) from BOM.BOM_EXPLOSION_TEMP;
prompt select count(*) from BOM.CST_EXPLOSION_TEMP;
select count(*) from BOM.CST_EXPLOSION_TEMP;
prompt select count(*) from BOM.BOM_LISTS;
select count(*) from BOM.BOM_LISTS;
prompt select count(*) from BOM.CST_LISTS;
select count(*) from BOM.CST_LISTS;
prompt select count(*) from mrp.MRP_ATP_DETAILS_TEMP;
select count(*) from mrp.MRP_ATP_DETAILS_TEMP;
prompt select count(*) from mrp.MRP_ATP_SCHEDULE_TEMP;
select count(*) from mrp.MRP_ATP_SCHEDULE_TEMP;
-- prompt APPLSYS.FND_LOG_EXCEPTIONS:
-- select count(*) from APPLSYS.FND_LOG_EXCEPTIONS;
-- prompt APPLSYS.FND_LOG_MESSAGES:
-- select count(*) from APPLSYS.FND_LOG_MESSAGES;
-- prompt APPLSYS.FND_LOG_UNIQUE_EXCEPTIONS:
-- select count(*) from APPLSYS.FND_LOG_UNIQUE_EXCEPTIONS;
prompt selct count(*) from INV.MTL_SUPPLY_DEMAND_TEMP
select count(*) from INV.MTL_SUPPLY_DEMAND_TEMP;

