-- after purging temp tables, do the following index rebuild and stats gathering for performance
-- ew 12/2006

-- truncate table BOM.CST_LOW_LEVEL_CODES;
alter index bom.CST_LOW_LEVEL_CODES_N1 rebuild online;
alter index bom.CST_LOW_LEVEL_CODES_N2 rebuild online;
exec fnd_stats.gather_table_stats (tabname => 'CST_LOW_LEVEL_CODES', ownname => 'BOM', cascade => TRUE);

-- truncate table BOM.CST_EXPLOSION_TEMP;
alter index bom.CST_EXPLOSION_TEMP_N1 rebuild online;
alter index bom.CST_EXPLOSION_TEMP_N2 rebuild online;
alter index bom.CST_EXPLOSION_TEMP_N3 rebuild online;
exec fnd_stats.gather_table_stats (tabname => 'CST_EXPLOSION_TEMP', ownname => 'BOM', cascade => TRUE);
