set lines 130 pages 50
col user_concurrent_program_name for a35
col argument_text for a45 trunc
Select request_id, user_name,  user_concurrent_program_name,
(actual_completion_date - actual_start_date)*24*3600 Duration
, phase_code, status_code, argument_text
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and (actual_completion_date - actual_start_date)*24*3600 > 60
And user_concurrent_program_name like 'PX%'
order by 3
/
