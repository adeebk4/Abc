select count(*) from mtl_system_items_interface;
select count(*) from mtl_item_revisions_interface;
select count(*) from mtl_item_categories_interface;
select count(*) from mtl_interface_errors;
