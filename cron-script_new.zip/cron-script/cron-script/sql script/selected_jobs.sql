col "Duration (Min)" for 999
col "Duration (Min)" heading "Duration|(Min)"
col argument_text for a30 truncate
col Start_Date for a17
col End_Date for a17
col user_concurrent_program_name for a35
Select user_concurrent_program_name, request_id, to_char(actual_start_date, 'Mon dd HH24:MI:SS') Start_Date,
to_char(actual_completion_date, 'Mon dd HH24:MI:SS') End_date,
(actual_completion_date - actual_start_date)*24*60 "Duration (Min)"
, phase_code, status_code,argument_text
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c, v$session d
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and a.os_process_id=d.process(+)
and c.language = 'US' and user_name='ERICWANG'
And  phase_code='C' and status_code='C' and user_concurrent_program_name in
('PX Sales Detail By Month With Invoice', 'PX Shipping Analysis Report', 'Refresh Snapshots', 'Gather Schema Statistics')
order by user_concurrent_program_name, 2
/

