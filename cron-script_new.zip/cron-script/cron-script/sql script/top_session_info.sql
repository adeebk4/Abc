set pages 0 verify off feed off 
col  user_name for a12 truncate
col ora_pid  for a8 
col os_pid for a8
col type for a11
col machine for a9
col program for a30 truncate
select oracle_process_id ora_pid, os_process_id os_pid, 'Concurrent' type, 
b.user_name user_name, 'pxrdb2' machine, user_concurrent_program_name program  
from fnd_concurrent_requests a, fnd_user b, 
fnd_concurrent_programs_tl c
where a.requested_by=b.user_id
and a.concurrent_program_id=c.concurrent_program_id
and phase_code = 'R' 
and oracle_process_id=&&1
UNION ALL
select process_spid ORA_PID, process OS_PID, 'Forms' type, user_name, machine, user_form_name program
from fnd_form_sessions_v a, v$session b
where a.sid=b.sid and a.serial#=b.serial#
and process_spid=&&1
# UNION ALL
# select spid ora_pid, process os_pid, 'Unknown' type, '' user_name, machine, module program
#  from v$process a, v$session b
# where a.addr=b.paddr
# and spid not in
# ((select oracle_session_id from fnd_concurrent_requests where phase_code='R'),
# (select process_spid from fnd_form_sessions_v))
# and spid=&&1
/
