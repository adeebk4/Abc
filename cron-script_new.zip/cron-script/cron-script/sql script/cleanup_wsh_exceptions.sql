declare
counter number :=0;
cursor del_c is select exception_id from wsh_exceptions
where status ='NO_ACTION_REQUIRED' and creation_date < sysdate - 2;
del_p del_c%rowtype;
Begin
open del_c;
LOOP
fetch del_c into del_p;
delete from wsh_exceptions where exception_id = del_p.exception_id;
counter := counter + 1;
if counter = 500 then
commit;
counter := 0;
end if;
end loop;
commit;
END;
/
