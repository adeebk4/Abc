-- for setting session NLS_LANGUAGE value
-- From Metalink Doc 260523.995
-- EWang 8/29/2005
begin 
FND_GLOBAL.set_nls_context 
(p_nls_language => '&NLS_LANG', 
p_nls_date_format => null, 
p_nls_date_language => null, 
p_nls_numeric_characters => '.,', 
p_nls_sort => null, 
p_nls_territory=> null); 
end; 
/
