set head off echo off feed off pages 0
Select 'alter index '||owner||'.'||index_name||' rebuild online;' from dba_indexes
Where table_name = upper('&Segment_name') and table_owner='&OWNER';

