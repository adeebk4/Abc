
grant select on APPS.PX_GAP_ITEMS_V to select_role;
grant select on APPS.AD_BI_DG_INVOICE_V to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42892 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42913 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42872 to select_role;
grant select on APPLSYS.AD_TUMS_STEPS to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42912 to select_role;
grant select on APPS.PX_INV_LK_FS_STG_V to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42932 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42832 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42833 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42834 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42852 to select_role;

grant select on APPS.FA_JOURNALS_INTERIM_42853 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42854 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42855 to select_role;
grant select on APPS.FA_JOURNALS_INTERIM_42812 to select_role;
