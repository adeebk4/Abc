alter table bom.CST_ELEMENTAL_COSTS move storage (initial 200M next 50M) tablespace bomd parallel 4;
alter table bom.CST_STANDARD_COSTS move storage (initial 200M next 50M) tablespace bomd parallel 4;
alter table bom.CST_STD_COST_ADJ_VALUES move storage (initial 200M next 50M) tablespace bomd parallel 4;
alter table bom.CST_PERIOD_CLOSE_SUMMARY move storage (initial 200M next 50M) tablespace bomd parallel 4;
