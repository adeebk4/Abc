﻿begin
	delete from paxar.px_mls_doc_label
	where report_name in (select distinct report_name from hkapps.temp_px_mls_doc_label);
	
	commit;
end;
/ 
exit;