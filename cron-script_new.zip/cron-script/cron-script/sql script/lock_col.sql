set serveroutput on size 1000000
set verify off
ACCEPT DEL_DETAIL_ID NUMBER PROMPT 'PLEASE ENTER DELIVERY_DETAIL_ID : '

DECLARE
  CURSOR C1 is
    Select column_name from dba_tab_columns
                       Where owner='ONT' and table_name = 'WSH_DELIVERY_DETAILS'
          order by column_name;

  Cnt       NUMBER(10) := 0;
  DynSql    VARCHAR2(1000);
  DelDetId  WSH_DELIVERY_DETAILS.Delivery_Detail_Id%TYPE;

BEGIN

  dbms_output.put_line('Script to identify the problematic fields :');
  dbms_output.put_line('============================================');

  FOR i IN C1 LOOP

    DelDetId := &DEL_DETAIL_ID;
    DynSql := 'SELECT COUNT(*) FROM WSH_DELIVERY_DETAILS ';
    DynSql := DynSql || 'WHERE NVL(LENGTH(LTRIM(RTRIM(' || i.column_name || '))), 0) <> ';
    DYNSql := DynSql || '      LENGTH(' || i.column_name || ') ';
    DynSql := DynSql || 'AND Delivery_Detail_Id = ' || DelDetId;

    EXECUTE IMMEDIATE DynSql INTO Cnt;
    IF ( cnt > 0 ) THEN
      dbms_output.put_line('Field "' ||i.COLUMN_NAME|| '" for delivery detail '
                         || DelDetId || ' has leading or trailing spaces');
    END IF;

  END LOOP;

  dbms_output.put_line('Script completed succefully.......');

END;
/
