Set head off feed off
Select 'The following queries were done on '|| to_char(sysdate, 'mm-dd-yy HH24:MI:SS') from dual;

Set pages 50 lines 130 head on 
prompt
prompt -- Total free space in the two rollback tablespaces
 
select tablespace_name, sum(bytes) from dba_free_space where tablespace_name like 'RBS%' group by tablespace_name;

prompt -- Sessions using more than one rollback segment block

Col module for a15
Col username for a12
col "ROLLBACK SEG" for a14
col process for a12
select s.sid, s.username, s.module, s.osuser,s.process, r.name "ROLLBACK SEG", t.used_ublk "Rollback Used" 
  from v$session s, v$transaction t, v$rollname r 
 where s.taddr=t.addr 
  and  t.xidusn = r.usn and t.used_ublk>1; 

prompt -- Status of all rollback segments 

select a.usn, name, rssize, xacts, status, gets, waits from v$rollname a, v$rollstat b where a.usn=b.usn;

