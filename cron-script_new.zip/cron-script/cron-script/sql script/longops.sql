set linesize 200
col sid format 999999 
col message format a100
col module format a30
select sl.sid,s.module,sl.message,sl.time_remaining from v$session_longops sl,v$session s  where s.sid=sl.sid and sl.time_remaining>0;

SELECT SID, SERIAL#, opname, SOFAR, TOTALWORK,
ROUND(SOFAR/TOTALWORK*100,2) COMPLETE
FROM   V$SESSION_LONGOPS
WHERE
TOTALWORK != 0
AND    SOFAR != TOTALWORK
order by 1;
