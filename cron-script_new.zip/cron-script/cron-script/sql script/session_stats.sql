select name, value from v$statname a,  v$sesstat b where a.STATISTIC#=b.STATISTIC# and sid=&SID and value > 0;
