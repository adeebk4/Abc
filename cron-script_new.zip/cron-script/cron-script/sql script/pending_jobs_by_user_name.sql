col user_name for a25
col user_concurrent_program_name for a35 trunc
col resubmit_interval heading "Resub|Intv"
col RESUBMIT_INTERVAL_UNIT_CODE for a10 heading "Resub|Code"
Select user_name, request_id, user_concurrent_program_name, to_char(requested_start_date, 'yyyy-mm-dd HH24:MI:SS') Req_Start_Date,
resubmit_interval, RESUBMIT_INTERVAL_UNIT_CODE 
-- , RESUBMIT_INTERVAL_UNIT_CODE, RESUBMIT_INTERVAL_TYPE_CODE
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and language='US'
and user_name='&User_Name'
And  phase_code='P' 
order by 3
/
