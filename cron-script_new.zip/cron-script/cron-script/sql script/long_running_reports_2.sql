set lines 130 pages 50
col "Duration (Min)" heading "Duration|(Min)"
col user_concurrent_program_name for a35
-- col argument_text for a40 trunc
col user_name for a20
spool long_running_reports_1.lst
Select request_id, user_name,  user_concurrent_program_name,
trunc((actual_completion_date - actual_start_date)*24*60) "Duration (Min)"
, phase_code, status_code,oracle_process_id SPID, os_process_id OSID, 
to_char(actual_start_date, 'YYYY-MM-DD HH24:MI:SS') Start_Time, to_char(actual_completion_date, 'YYYY-MM-DD HH24:MI:SS') Compl_Time 
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and c.language='US'
-- and actual_start_date> (sysdate - 0.5) -- last half day
-- changed from 1200 to 1800 below on Feb 14, 2006
and (actual_completion_date - actual_start_date)*24*60 > 30 -- over 30 minutes
order by 3
/
spool off
!mail -s "Long Running Reports in Past 3 Days" "eric.wang@paxar.com" <long_running_reports_1.lst
!mv long_running_reports_1.lst long_running_reports/long_running_reports_2_$(date +%Y%m%d).lst
