SELECT 'ALTER SYSTEM KILL SESSION '||Chr(39)||s.sid||','||s.serial#|| Chr(39)||' immediate;'
from v$session s where status like 'INACTIVE' and logon_time < sysdate-4/24 and action like 'FRM:%'  and last_call_et/60>120;
