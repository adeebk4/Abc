set heading off
set feedback off
set pagesize 0
spool kill_session.sql
SELECT 'ALTER SYSTEM KILL SESSION '||''''||sid ||','|| serial#||''''||' immediate;'
from v$session where last_call_et > 2*3600 and event='SQL*Net message from client' and upper(nvl(program, 'aaa')) NOT like '%JDBC%';
spool off

@kill_session.sql;
