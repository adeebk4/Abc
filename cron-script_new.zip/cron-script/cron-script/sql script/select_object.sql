col object_name for a36
col object_type for a20
col owner for a20
set pages 50 lines 130
select object_id, object_name, object_type, owner from dba_objects where object_name like '&Object_name%';

