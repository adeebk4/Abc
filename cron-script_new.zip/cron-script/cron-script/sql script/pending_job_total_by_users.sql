col user_name for a25
Select user_name, count(*)
From fnd_concurrent_requests a, fnd_user b
Where a.requested_by=b.user_id
And  phase_code='P' 
group by user_name having count(*) > 10
order by count(*)
/
