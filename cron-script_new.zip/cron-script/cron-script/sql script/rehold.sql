declare
  GV_HOLD_NAME VARCHAR2(50) := 'LC SHIPPING HOLD';
  LV_REL_CODE        VARCHAR2(150) := 'MAN_REL';--'LC_AVAILABLE';
  LV_ERRBUF          VARCHAR2(2000);
  LN_RETCODE         NUMBER;
  LT_ORDER           OE_HOLDS_PVT.ORDER_TBL_TYPE;
  LV_REL_COMMENTS    VARCHAR2(2000);
  ln_count           number:=0;
  

  cursor c_so is
    SELECT OOL.LINE_ID,OOL.HEADER_ID,OOL.BLANKET_NUMBER,OOL.BLANKET_LINE_NUMBER,OOL.LAST_UPDATED_BY,
           OOH.ORDER_NUMBER,OOL.LINE_NUMBER||'.'||OOL.SHIPMENT_NUMBER LINE_NUM
      FROM OE_ORDER_LINES_ALL OOL,
           OE_ORDER_HEADERS_ALL OOH
     WHERE OOL.HEADER_ID=OOH.HEADER_ID
       AND 1 = 1
       AND EXISTS
     (SELECT 1
              FROM OE_TRANSACTION_TYPES_TL OT, OE_ORDER_HEADERS_ALL OOH
             WHERE OT.TRANSACTION_TYPE_ID = OOH.ORDER_TYPE_ID
               AND OOH.HEADER_ID = OOL.HEADER_ID
               AND OT.LANGUAGE = 'US'
               AND OT.NAME not IN ('BDP STD',
                                   'BDP EXP',
                                   'BDP 24HR',
                                   'BDP 48HR',
                                   'BDP URG',
                                   'BDP IC'))
       AND OOL.ORG_ID = 3720
       AND EXISTS
     (SELECT 1
              FROM OE_ORDER_HOLDS_ALL  OH,
                   OE_HOLD_SOURCES_ALL HS,
                   OE_HOLD_DEFINITIONS OD
             WHERE OH.HOLD_SOURCE_ID = HS.HOLD_SOURCE_ID
               AND OD.HOLD_ID = HS.HOLD_ID
               AND NVL(OH.RELEASED_FLAG, 'N') <> 'Y'
               AND OD.NAME = GV_HOLD_NAME
               AND OH.LINE_ID = OOL.LINE_ID)
       AND ool.creation_date >= to_date('2015-10-01', 'yyyy-mm-dd');


begin
                                  
  DBMS_APPLICATION_INFO.SET_CLIENT_INFO(3720);  


  for s_so in c_so loop
    ln_count := ln_count + 1;
    dbms_output.put_line('release hold Order_number:'|| s_so.order_number||';'||'Line_num:'||s_so.line_num);
    LT_ORDER(1).HEADER_ID := s_so.HEADER_ID;
    LT_ORDER(1).LINE_ID := s_so.LINE_ID;
    LV_REL_COMMENTS := 'LC not require';

    apps.px_bd_release_so_pkg.RELEASE_HOLD_API(I_ORD_TBL         => LT_ORDER,
                                               I_CHR_HOLD_NAME   => GV_HOLD_NAME,
                                               I_CHR_REL_CODE    => LV_REL_CODE,
                                               I_CHR_REL_COMMENT => LV_REL_COMMENTS,
                                               O_CHR_ERRBUF      => LV_ERRBUF,
                                               O_NUM_RETCODE     => LN_RETCODE);
    if ln_retcode = 2 then
      dbms_output.put_line('Error:'||LV_ERRBUF||';Error Code:'||LN_RETCODE);
    else
      dbms_output.put_line('Success');
    end if;
  
  end loop;
  
  if ln_count =0 then
    dbms_output.put_line('No Sales Order Released');
  else
    dbms_output.put_line('Total:'|| ln_count ||' Sales Order Lines Released');
  end if;
  
  commit;
--rollback;
exception
  when others then
    rollback;
    dbms_output.put_line('when Exception,rollback');

end;
/

