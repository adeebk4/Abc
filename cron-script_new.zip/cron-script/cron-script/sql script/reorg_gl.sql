spool GL_int_table_reorg_log.txt

select to_char(sysdate,'YYYY/MM/DD HH24:MI:SS') START_TIME from dual;

SELECT /* + RULE */ df.tablespace_name "Tablespace",
df.bytes / (1024 * 1024) "Size (MB)",
SUM(fs.bytes) / (1024 * 1024) "Free (MB)",
Nvl(Round(SUM(fs.bytes) * 100 / df.bytes),1) "% Free",
Round((df.bytes - SUM(fs.bytes)) * 100 / df.bytes) "% Used"
FROM dba_free_space fs,
(SELECT tablespace_name,SUM(bytes) bytes
FROM dba_data_files
GROUP BY tablespace_name) df
WHERE fs.tablespace_name (+) = df.tablespace_name
and df.tablespace_name in ('GLD')
GROUP BY df.tablespace_name,df.bytes
ORDER BY 5 desc;

select owner,segment_name,segment_type,bytes/1024/1024/1024 GB from dba_segments where segment_type='TABLE' and segment_name in ('GL_CONS_INTERFACE_7472952','GL_CONS_INTERFACE_7472950');

alter table GL.GL_CONS_INTERFACE_7472952 move;
alter table GL.GL_CONS_INTERFACE_7472950 move;

alter index GL.GL_CONS_INTERFACE_7472952_N2 rebuild parallel 4 nologging;
alter index GL.GL_CONS_INTERFACE_7472950_N2 rebuild parallel 4 nologging;


SELECT /* + RULE */ df.tablespace_name "Tablespace",
df.bytes / (1024 * 1024) "Size (MB)",
SUM(fs.bytes) / (1024 * 1024) "Free (MB)",
Nvl(Round(SUM(fs.bytes) * 100 / df.bytes),1) "% Free",
Round((df.bytes - SUM(fs.bytes)) * 100 / df.bytes) "% Used"
FROM dba_free_space fs,
(SELECT tablespace_name,SUM(bytes) bytes
FROM dba_data_files
GROUP BY tablespace_name) df
WHERE fs.tablespace_name (+) = df.tablespace_name
and df.tablespace_name in ('GLD')
GROUP BY df.tablespace_name,df.bytes
ORDER BY 5 desc;

select owner,segment_name,segment_type,bytes/1024/1024/1024 GB from dba_segments where segment_type='TABLE' and segment_name in ('GL_CONS_INTERFACE_7472952','GL_CONS_INTERFACE_7472950');

select to_char(sysdate,'YYYY/MM/DD HH24:MI:SS') END_TIME from dual;
spool off;
