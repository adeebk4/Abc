-- script for querying total number of rows in the 20 or so biggest tables
-- EW Jan 6, 2006
  --  select 'select count(*) from '||owner||'.'||segment_name||';' from dba_segments
  -- where segment_type = 'TABLE' and bytes > 2500000000 order by bytes
  -- ;
set echo on feed on
spool select_big_tables.lst
select count(*) from AR.RA_CUST_TRX_LINE_GL_DIST_ALL;                                                                             
select count(*) from DIS.PX_SALES_MKT_HISTORY;                                                                                    
--select count(*) from PRECISE.REFERTAB;                                                                                            
select count(*) from AR.RA_CUSTOMER_TRX_LINES_ALL;                                                                                
select count(*) from AR.AR_RECEIPTS_REP_ITF;                                                                                      
select count(*) from GL.GL_INTERFACE_HISTORY;                                                                                     
--select count(*) from APPLSYS.DR$FND_LOBS_CTX$I;                                                                                   
select count(*) from GL.GL_IMPORT_REFERENCES;                                                                                     
select count(*) from MRP.MRP_BOM_COMPONENTS;                                                                                      
--select count(*) from PRECISE.PREDTAB;                                                                                             
--select count(*) from PRECISE.TMP_PREDTAB;                                                                                         
select count(*) from MRP.MRP_PLANNED_RESOURCE_REQS;                                                                               
select count(*) from MRP.MRP_SYSTEM_ITEMS;                                                                                        
select count(*) from WSH.WSH_EXCEPTIONS;                                                                                          
select count(*) from WIP.WIP_TRANSACTION_ACCOUNTS;                                                                                
select count(*) from PAXAR.PX_INVOICES;                                                                                           
select count(*) from INV.MTL_CST_ACTUAL_COST_DETAILS;                                                                             
select count(*) from MSC.MSC_BOR_REQUIREMENTS;                                                                                    
select count(*) from INV.MTL_MATERIAL_TRANSACTIONS;                                                                               
select count(*) from INV.MTL_TRANSACTION_ACCOUNTS;                                                                                
select count(*) from METRIX.PART_TRANLOG;                                                                                         
select count(*) from MSC.MSC_OPERATION_COMPONENTS;                                                                                
select count(*) from BOM.CST_ITEM_COST_DETAILS;                                                                                   
select count(*) from INV.MTL_TXN_REQUEST_LINES;                                                                                   
spool off
!mv select_big_tables.lst log/select_big_tables_`date +%Y%m%d`.lst
