-- modified from Metalink Doc 34579.1, ew 20050210
-- the pinning sessions, must run as SYS
  SELECT s.sid, kglpnmod "Mode", kglpnreq "Req", s.paddr
    FROM x$kglpn p, v$session s, v$session_wait w
   WHERE p.kglpnuse=s.saddr And s.sid = w.sid   AND kglpnhdl=w.P1RAW
And w.event = 'library cache pin'
/
-- An X request (3) will be blocked by any pins held S mode (2) on the object.
-- An S request (2) will be blocked by any X mode (3) pin held, or may queue behind some other X request.
-- 
-- The session that holds the pin (with a Mode value) needs to be killed:
-- 
-- Select a.sid, a.serial#, 'kill -9 '|| spid from v$session a, v$process b
-- Where a.paddr=b.addr and a.sid=&SID;
