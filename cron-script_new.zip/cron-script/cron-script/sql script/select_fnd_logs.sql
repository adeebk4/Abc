set echo on feed on
select count(*) from FND_EXCEPTION_NOTES;
select count(*) from FND_OAM_BIZEX_SENT_NOTIF;
select count(*) from FND_LOG_METRICS;
select count(*) from FND_LOG_UNIQUE_EXCEPTIONS;
select count(*) from FND_LOG_EXCEPTIONS;
select count(*) from FND_LOG_MESSAGES;
select count(*) from FND_LOG_TRANSACTION_CONTEXT;
select count(*) from FND_LOG_ATTACHMENTS;
