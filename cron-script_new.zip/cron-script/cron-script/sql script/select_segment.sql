col segment_name for a30
col segment_type for a15
col tablespace_name for a15
select segment_name, segment_type, bytes, extents, initial_extent, next_extent, max_extents, tablespace_name from dba_segments
where owner='&Owner' and segment_name like upper('&Segment_Name%')
/
