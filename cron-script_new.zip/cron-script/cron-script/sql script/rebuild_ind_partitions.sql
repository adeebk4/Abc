alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_2 online parallel 16;

'ALTERINDEXMSC.'||INDEX_NAME||'REBUILDPARTITION'||PARTITION_NAME||'ONLINEPARALLEL16;'
-------------------------------------------------------------------------------------------------------------------
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_5 online parallel 16;

'ALTERINDEXMSC.'||INDEX_NAME||'REBUILDPARTITION'||PARTITION_NAME||'ONLINEPARALLEL16;'
-------------------------------------------------------------------------------------------------------------------
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_0 online parallel 16;

'ALTERINDEXMSC.'||INDEX_NAME||'REBUILDPARTITION'||PARTITION_NAME||'ONLINEPARALLEL16;'
-------------------------------------------------------------------------------------------------------------------
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_3 online parallel 16;

'ALTERINDEXMSC.'||INDEX_NAME||'REBUILDPARTITION'||PARTITION_NAME||'ONLINEPARALLEL16;'
-------------------------------------------------------------------------------------------------------------------
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;

'ALTERINDEXMSC.'||INDEX_NAME||'REBUILDPARTITION'||PARTITION_NAME||'ONLINEPARALLEL16;'
-------------------------------------------------------------------------------------------------------------------
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS__1 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_0 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_1 online parallel 16;

'ALTERINDEXMSC.'||INDEX_NAME||'REBUILDPARTITION'||PARTITION_NAME||'ONLINEPARALLEL16;'
-------------------------------------------------------------------------------------------------------------------
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_2 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_3 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_4 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_5 online parallel 16;
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_999999 online parallel 16;
