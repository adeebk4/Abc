set pages 50 
set echo on feed on
spool temp_cleanup.log
select count(*) from bom.CST_LOW_LEVEL_CODES;
select count(*) from bom.CST_STD_COST_ADJ_TEMP;
select count(*) from bom.bom_explosion_temp;
select count(*) from bom.cst_explosion_temp;
select count(*) from bom.bom_lists;
select count(*) from bom.cst_lists;
select count(*) from mrp.MRP_ATP_DETAILS_TEMP;
select count(*) from mrp.MRP_ATP_schedule_TEMP;
-- select count(*) from bom.CST_ITEM_COSTS where cost_type_id <0;
-- select count(*) from bom.CST_ITEM_COST_DETAILS where cost_type_id <0;

prompt TRUNCATE and DELETE:
truncate table bom.CST_LOW_LEVEL_CODES;
truncate table bom.CST_STD_COST_ADJ_TEMP;
Truncate table bom.bom_explosion_temp;
Truncate table bom.cst_explosion_temp;
Truncate table bom.bom_lists;
Truncate table bom.cst_lists;
-- delete from bom.CST_ITEM_COSTS where cost_type_id <0;
-- delete from bom.CST_ITEM_COST_DETAILS where cost_type_id <0;
TRUNCATE TABLE MRP.MRP_ATP_DETAILS_TEMP;
TRUNCATE TABLE MRP.MRP_ATP_SCHEDULE_TEMP;

prompt Gather stats:
exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'CST_LOW_LEVEL_CODES');
exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'CST_STD_COST_ADJ_TEMP');
exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'BOM_EXPLOSION_TEMP');
exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'CST_EXPLOSION_TEMP');
exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'BOM_LISTS');
exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'CST_LISTS');
-- exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'CST_ITEM_COSTS');
-- exec fnd_stats.gather_table_stats(ownname => 'BOM', tabname => 'CST_ITEM_COST_DETAILS');
Exec fnd_stats.gather_table_stats(ownname => 'MRP', tabname=>'MRP_ATP_DETAILS_TEMP');
Exec fnd_stats.gather_table_stats(ownname => 'MRP', tabname=>'MRP_ATP_SCHEDULE_TEMP');

spool off
!mv temp_cleanup.log temp_cleanup.log_`date +%y%m%d`.log
