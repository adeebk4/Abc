select bill_sequence_id, PK1_VALUE, PK2_VALUE, ALTERNATE_BOM_DESIGNATOR  FROM BOM.BOM_STRUCTURES_B
where pk1_value ='&pk1_value' and pk2_value='&pk2_value'
/
