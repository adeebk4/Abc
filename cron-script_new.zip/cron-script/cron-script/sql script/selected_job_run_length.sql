spool selected_job_run_length_1.log
define user_concurrent_program_name='PX Tax Category Update'
define Argument_Text=''
@job_run_length_by_program_all

define user_concurrent_program_name='PX Components Dispatch Report (by Job Status)'
define Argument_Text='1957, JOB NUMBER, DETAIL, , , , , , , , , , SZGM110, SZGMATO600'
@job_run_length_by_program_all

define user_concurrent_program_name='PX Create Bookings Extract Table'
define Argument_Text=''
@job_run_length_by_program_all

define user_concurrent_program_name='Memory-based Snapshot'
define Argument_Text='5, DRP-LN-SH'
@job_run_length_by_program_all

define user_concurrent_program_name='Memory-based Snapshot'
define Argument_Text='1039, MPS-PFE'
@job_run_length_by_program_all

define user_concurrent_program_name='Calculate End Assemblies'
define Argument_Text='ORG_ID=5, COMPILE_DESIG=DRP-LN-SH'
@job_run_length_by_program_all

define user_concurrent_program_name='PX EMEA Customer Aging Report'
define Argument_Text='1117, , , , , , , , , Y, , , , Collections, , , Y'
@job_run_length_by_program_all

define user_concurrent_program_name='Gather Schema Statistics'
define Argument_Text='ALL, 20, , NOBACKUP, , LASTRUN, GATHER, , Y'
@job_run_length_by_program_all

define user_concurrent_program_name='Purge ODS Data of Collections'
define Argument_Text=''
@job_run_length_by_program_all

define user_concurrent_program_name='Refresh Snapshots'
define Argument_Text='2, ALL SNAPSHOTS, , 0'
@job_run_length_by_program_all

define user_concurrent_program_name='Planning ODS Load Worker'
define Argument_Text='%360, 1, 2, 1, 1'
@job_run_length_by_program_all

-- define user_concurrent_program_name=''
-- define Argument_Text=''
-- @job_run_length_by_program_all

spool off
undefine user_concurrent_program_name
!cp selected_job_run_length_1.log log/selected_job_run_length_$(date +%Y%m%d).log

