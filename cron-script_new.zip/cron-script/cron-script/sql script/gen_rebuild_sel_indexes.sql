set echo off
set feedback off
set ver off
set heading off
set pagesize 4000
select 'set timing on' from dual;
select 'set echo on' from dual;
REM select 'spool rebuild_all_indexes.log'  from dual;
select 'alter index ' || owner || '.' || index_name || ' rebuild online ;'
from dba_indexes
-- where owner not in ('SYS','SYSTEM', 'MDSYS','CTXSYS', 'ORDSYS','PRECISE','VRTSI3PW')
where owner in ('INV','BOM','APPLSYS')
order by owner;
select 'exit' from dual;
REM spool off
exit
