REM select count(*) from CST_STD_COST_ADJ_TEMP;
REM select count(*) from CST_STD_COST_ADJ_VALUES;
REM select count(*) from WIP_SCRAP_VALUES;
REM select count(*) from CST_ITEM_COSTS;
REM select count(*) from cst_cost_updates ;
REM select count(*) from cst_elemental_costs ;
REM select count(*) from cst_standard_costs   ;
REM select count(*) from BOM_EXPLOSION_TEMP;
REM select count(*) from CST_EXPLOSION_TEMP;
REM select count(*) from CST_ROLLUP_DELETE_TEMP;
REM select count(*) from CST_STD_COST_ADJ_TEMP;
REM select count(*) from CST_LOW_LEVEL_CODES;
REM select count(*) from cst_item_costs where cost_type_id <0;
REM select count(*) from cst_item_cost_details where cost_type_id <0;
REM select count(*) from BOM_SMALL_EXPL_TEMP;
REM select count(*) from BOM_SMALL_IMPL_TEMP;
REM select count(*) from BOM_LISTS;
REM select count(*) from CST_LOW_LEVEL_CODES;
set echo on
select count(*) from BOM_EXPLOSION_TEMP;
select count(*) from CST_EXPLOSION_TEMP;
select count(*) from CST_ROLLUP_DELETE_TEMP;
select count(*) from CST_STD_COST_ADJ_TEMP;
select count(*) from CST_LOW_LEVEL_CODES;
select count(*) from BOM_LISTS;
select count(*) from CST_LISTS;
select count(*) from cst_item_costs where cost_type_id <0;
select count(*) from cst_item_cost_details where cost_type_id <0;

