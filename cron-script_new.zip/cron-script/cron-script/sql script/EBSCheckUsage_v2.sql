REM Copyright (c) 2016 Oracle Corporation  - All rights reserved.
REM
REM run as APPS (really <FNDNAM>)
REM 
REM Usage: sqlplus APPS  @EBSCheckUsage
REM
REM This script will check product usage 
REM 
REM ----------------------------------------------------------------------------

set pagesize 999
set linesize 132
set feedback 1
set verify   off
set echo     off
set tab      on
set trim     on

spool EBSCheckUsage.txt

Prompt ==================================================
Prompt = Database NAME @ HOST - SW Versions - DATE of run
Prompt ==================================================
col "EBS Release" format a12
col "Database Identification" format a50
select INSTANCE_NAME|| ' @ ' ||HOST_NAME "Database Identification", VERSION "DB Version",  RELEASE_NAME "EBS Release", SYSDATE 
  from v$INSTANCE, FND_PRODUCT_GROUPS
/


Prompt ==================================================
Prompt = Product Usage
Prompt ==================================================

select 'CRM_AMS' "Product Usage",count(*) from AMS_CAMPAIGN_SCHEDULES Where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_AMV', count(*) from AMV_C_CATEGORIES_B Where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_ASF', count(*)  from AS_LEADS_ALL where LAST_UPDATE_DATE > add_months(sysdate,-12) 
UNION select 'CRM_ASL', count(*) from bne_async_upload_jobs where integrator_app_id = 544 and integrator_code = 'SALES_OFFLINE' and job_creation_date > add_months(sysdate , -12)
UNION select 'CRM_ASOBI', count(*) From ASO_BI_QUOTE_HDRS_ALL Where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_ASP', count(*) from cac_sync_anchors where server_uri in ('./tasks','./contacts', './appointments') and last_sync_date >= add_months(sysdate,-12)
UNION select 'CRM_BIL', count(*) From BIL_BI_OPDTL_F Where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION Select 'CRM_BIM', count(*) From BIM_I_LEAD_FACTS Where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_CSK', count(*) from cs_kb_sets_b where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_CSM', count(*) from asg_user WHERE last_synch_date_end > add_months(sysdate,-12) 
UNION select 'CRM_IBE', count(*) from ASO_QUOTE_HEADERS_ALL Where  LAST_UPDATE_DATE > add_months(sysdate,-12) And    QUOTE_SOURCE_CODE = 'IStore Account'
UNION select 'CRM_IBU', count(*) from cs_incidents_all_b where creation_program_code ='ISUPPORTSRUI' and LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_IEC', count(*) from IEC_G_RETURN_ENTRIES where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_IEM', count(*) from jtf_ih_media_items where media_item_type='EMAIL' and  LAST_UPDATE_DATE  > add_months(sysdate,-12) 
UNION select 'CRM_JTO', count(*) from jtf_fm_processed where last_update_date > add_months(sysdate,-12)
UNION select 'CRM_PV', count(*) from PV_PARTNER_PROFILES where LAST_UPDATE_DATE > add_months(sysdate,-12)
UNION select 'CRM_QOT', count(*) from ASO_QUOTE_HEADERS_ALL  Where  LAST_UPDATE_DATE > add_months(sysdate,-12) And QUOTE_SOURCE_CODE = 'Order Capture Quotes'
UNION select 'FIN_OZF', count(*) from OZF_CLAIMS_ALL Where LAST_UPDATE_DATE > add_months(sysdate,-12);

Prompt ==================================================
Prompt = FND Product Installations
Prompt ==================================================

col PRODUCT_CODE format a8
col APPLICATION_SHORT_NAME format a8
col product_version format a10
col patch_level format a15
select APPLICATION_SHORT_NAME,PRODUCT_CODE, PRODUCT_VERSION, STATUS, PATCH_LEVEL
from fnd_application fa,fnd_product_installations fpi
where fa.application_id=fpi.application_id;

Prompt ==================================================
Prompt = Done; Now review the results from the spool file
spool
Prompt
spool off
exit
