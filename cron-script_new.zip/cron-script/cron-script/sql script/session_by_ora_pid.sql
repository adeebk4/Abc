col program for a20
col module for a20
col osuser for a10
col machine for a15
select sid, serial#, process, action,program, module, osuser, machine from v$session
where paddr in
(select addr from v$process where spid='&Ora_Spid')
/
