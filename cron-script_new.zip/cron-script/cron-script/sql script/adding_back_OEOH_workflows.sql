undefine Item_Key
accept Item_Key prompt "Enter target item_key:"  
Insert into wf_items select * from wf_items@TO_PXR2 where item_type='OEOH' and item_key='&&Item_Key';

Insert into wf_item_activity_statuses select * from wf_item_activity_statuses@TO_PXR2 where item_type='OEOH' and item_key='&&Item_Key';

Insert into wf_item_activity_statuses_h select * from wf_item_activity_statuses_h@TO_PXR2 where item_type='OEOH' and item_key='&&Item_Key';

Insert into wf_item_attribute_values select * from wf_item_attribute_values@TO_PXR2 where item_type='OEOH' and item_key='&&Item_Key';

Insert into wf_notifications (select * from 
Wf_notifications@TO_PXR2 a where a.notification_id in (
Select distinct notification_id from 
Wf_item_activity_statuses@TO_PXR2 b where a.notification_id = b.notification_id and b.item_type='OEOH' and b.item_key='&&Item_Key'));

