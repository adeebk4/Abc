select a.sid, a.serial#, process, a.program, module,osuser, machine, status, 
to_char(logon_time,'MON-DD-YY HH24:MI:SS') LOGON_TIME, spid
 from v$session a, v$process b where a.paddr = b.addr and a.sid=&SID
/
