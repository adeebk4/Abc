set pages 0 verify off feed off lines 90
col  user_name for a12 truncate
col ora_pid  for a8
col os_pid for a8
col type for a11
col machine for a9
col program for a30 truncate
select spid ora_pid, process os_pid, 'Unknown' type, osuser user_name, machine, module program
 from v$process a, v$session b
where a.addr=b.paddr
and spid=&&1
/
exit
