set lines 130 pages 50
col "Duration (Min)" heading "Duration|(Min)"
col user_concurrent_program_name for a35
col argument_text for a40 trunc
col user_name for a25
-- spool long_running_reports_1.lst
spool &Program_Name
Select request_id||';'|| user_name||';'|| to_char(actual_start_date, 'yyyy-mm-dd HH24:MI:SS') ||';'|| 
trunc((actual_completion_date - actual_start_date)*24*60) ||';'||user_concurrent_program_name
||';'|| argument_text
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and a.program_application_id=c.application_id
and c.language='US'
and actual_start_date> (sysdate - 30) -- last half day
-- changed from 1200 to 1800 below on Feb 14, 2006
and (actual_completion_date - actual_start_date)*24*60 > 60 -- over 60 minutes, changed from 30 to 60, 5/1/2012
and user_concurrent_program_name = '&user_concurrent_program_name'
order by 1
/
-- spool off
