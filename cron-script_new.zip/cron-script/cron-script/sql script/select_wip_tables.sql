set echo on
select count(*) from WIP_DISCRETE_JOBS where creation_date < sysdate - 19;
select count(*) from WIP_MOVE_TRANSACTIONS where creation_date < sysdate - 19;
select count(*) from WIP_MOVE_TXN_ALLOCATIONS where creation_date < sysdate - 19;
select count(*) from WIP_OPERATIONS where creation_date < sysdate - 19;
select count(*) from WIP_OPERATION_RESOURCES where creation_date < sysdate - 19;
select count(*) from WIP_PERIOD_BALANCES where creation_date < sysdate - 19;
select count(*) from WIP_REPETITIVE_SCHEDULES where creation_date < sysdate - 19;
select count(*) from WIP_REQUIREMENT_OPERATIONS where creation_date < sysdate - 19;
select count(*) from WIP_SHOP_FLOOR_STATUSES where creation_date < sysdate - 19;
select count(*) from WIP_SO_ALLOCATIONS where creation_date < sysdate - 19;
select count(*) from WIP_TRANSACTIONS where creation_date < sysdate - 19;
select count(*) from WIP_TRANSACTION_ACCOUNTS where creation_date < sysdate - 19;
select count(*) from WIP_TXN_ALLOCATIONS where creation_date < sysdate - 19;
