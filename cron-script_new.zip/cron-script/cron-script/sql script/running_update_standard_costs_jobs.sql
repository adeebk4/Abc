Select user_name, request_id, user_concurrent_program_name,
(sysdate - actual_start_date)*24*3600 Duration
, phase_code, status_code, oracle_process_id Oracle_SPid, os_process_id OS_Id, d.sid SID
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c, v$session d
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and c.language = 'US'
and a.os_process_id=d.process(+) and user_concurrent_program_name='Update Standard Costs'
And  phase_code='R' and status_code='R'
order by 3
/
