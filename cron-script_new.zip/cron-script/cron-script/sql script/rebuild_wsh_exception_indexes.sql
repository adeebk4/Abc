  -- select 'alter index wsh.'||index_name||' rebuild online;' from dba_indexes where table_name='WSH_EXCEPTIONS' and owner='WSH'
alter index wsh.WSH_EXCEPTIONS_C1 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N2 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N14 rebuild online;                                                                                
alter index wsh.WSH_EXCEPTIONS_N7 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N8 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N9 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N13 rebuild online;                                                                                
alter index wsh.WSH_EXCEPTIONS_N10 rebuild online;                                                                                
alter index wsh.WSH_EXCEPTIONS_N11 rebuild online;                                                                                
alter index wsh.WSH_EXCEPTIONS_N12 rebuild online;                                                                                
alter index wsh.WSH_EXCEPTIONS_N6 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N3 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N4 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N5 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_N1 rebuild online;                                                                                 
alter index wsh.WSH_EXCEPTIONS_U1 rebuild online;                                                                                 

-- 16 rows selected.

