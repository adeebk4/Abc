select a.session_id, a.blocking_others, b.process from dba_locks a, v$session b where a.session_id = b.SID and a.blocking_others = 'Blocking';
