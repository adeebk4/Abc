col user_name for a25
col user_concurrent_program_name for a35 trunc
Select user_name, request_id, user_concurrent_program_name,
(sysdate - actual_start_date)*24*3600 Duration
, phase_code, status_code
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and language = 'US'
And  phase_code='P' 
order by 3
/
