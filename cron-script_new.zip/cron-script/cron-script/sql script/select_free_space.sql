prompt Please enter tablespace_name
select bytes from dba_free_space where tablespace_name='&Tablespace_Name' order by bytes;
