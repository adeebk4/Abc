set lines 130 pages 50
col "Duration (Min)" heading "Duration|(Min)"
col user_concurrent_program_name for a35
col argument_text for a40 trunc
col user_name for a25
spool long_running_reports_1.lst
Select request_id, user_name,  user_concurrent_program_name,
trunc((actual_completion_date - actual_start_date)*24*60) "Duration (Min)"
, phase_code, status_code, argument_text
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and a.program_application_id=c.application_id
and c.language='US'
-- and actual_start_date> (sysdate - 0.5) -- last half day
-- changed from 1200 to 1800 below on Feb 14, 2006
and (actual_completion_date - actual_start_date)*24*60 > 60 -- over 60 minutes, changed from 30 to 60, 5/1/2012
order by 3
/
spool off
-- !mail -s "Long Running Reports in Past 3 Days" "oracle.dbas@averydennison.com greg.madden@averydennison.com fred.buckman@averydennison.com scot.murray@averydennison.com" <long_running_reports_1.lst
!mv long_running_reports_1.lst long_running_reports/long_running_reports_$(date +%Y%m%d).lst
