set lines 130 pages 50
col "Duration (Min)" heading "Duration|(Min)"
col user_concurrent_program_name for a30 trunc
col argument_text for a30 trunc
col user_name for a15 trunc
-- spool long_running_reports_all.lst
Select user_concurrent_program_name, user_name,request_id,to_char(actual_completion_date,'yyyy-mm-dd HH24:MI:SS') Completion_Date, 
trunc((actual_completion_date - actual_start_date)*24*60) "Duration (Min)"
, phase_code, status_code, argument_text
From paxar.px_fnd_conc_req_history a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and a.program_application_id=c.application_id
and c.language='US'
and (actual_completion_date - actual_start_date)*24*60 > 30 -- over 30 minutes
union all
Select user_concurrent_program_name, user_name,request_id,to_char(actual_completion_date,'yyyy-mm-dd HH24:MI:SS') Completion_Date,
trunc((actual_completion_date - actual_start_date)*24*60) "Duration (Min)"
, phase_code, status_code, argument_text
From fnd_concurrent_requests a, fnd_user b, fnd_concurrent_programs_tl c
Where a.requested_by=b.user_id
And a.concurrent_program_id=c.concurrent_program_id
and a.program_application_id=c.application_id
and c.language='US'
and (actual_completion_date - actual_start_date)*24*60 > 30 -- over 30 minutes
order by actual_completion_date, request_id 
/
-- spool off
