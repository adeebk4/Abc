SQL> l
  1* select 'alter database rename file '''||member||''' to ''/u4'||substr(member, 4)||''';' from v$logfile
SQL> /

'ALTERDATABASERENAMEFILE'''||MEMBER||'''TO''/U4'||SUBSTR(MEMBER,4)||''';'                                                          
-----------------------------------------------------------------------------------------------------------------------------------
alter database rename file '/u01/oracle/proddata/log05a.dbf' to '/u41/oracle/proddata/log05a.dbf';                                 
alter database rename file '/u01/oracle/proddata/log04a.dbf' to '/u41/oracle/proddata/log04a.dbf';                                 
alter database rename file '/u01/oracle/proddata/log03a.dbf' to '/u41/oracle/proddata/log03a.dbf';                                 
alter database rename file '/u01/oracle/proddata/log02a.dbf' to '/u41/oracle/proddata/log02a.dbf';                                 
alter database rename file '/u01/oracle/proddata/log01a.dbf' to '/u41/oracle/proddata/log01a.dbf';                                 

SQL> spool off
