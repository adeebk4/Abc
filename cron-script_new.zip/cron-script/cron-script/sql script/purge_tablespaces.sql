-- purge the recyclebins for the following tablespaces, need to login as sysdba
set echo on
purge tablespace mscd;
purge tablespace mscx;
purge tablespace gld;
purge tablespace glx;
purge tablespace applsysd;
purge tablespace applsysx;
purge tablespace paxar;
purge tablespace users;

