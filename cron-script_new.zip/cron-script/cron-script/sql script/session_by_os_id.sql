col program for a20
col module for a20
col osuser for a10
col machine for a15
select a.sid, a.serial#, process, a.program, a.module, osuser, a.machine, spid from v$session a, v$process b
where a.paddr = b.addr and process='&os_id'
/
