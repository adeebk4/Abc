set echo on feed on
select count(*) from WF_ITEMS;
select count(*) from WF_ITEM_ACTIVITY_STATUSES;
select count(*) from WF_ITEM_ACTIVITY_STATUSES_H;
select count(*) from WF_ITEM_ATTRIBUTE_VALUES;
select count(*) from WF_NOTIFICATION_ATTRIBUTES;

