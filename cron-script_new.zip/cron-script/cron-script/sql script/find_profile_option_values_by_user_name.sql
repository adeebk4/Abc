col USER_PROFILE_OPTION_NAME for a35
col PROFILE_OPTION_VALUE for a50
col user_name for a20
set pages 50 lines 130 feed on
select USER_PROFILE_OPTION_NAME, user_name, PROFILE_OPTION_VALUE, c.last_update_date LAST_UPDATED
from fnd_profile_options a, fnd_profile_options_tl b, fnd_profile_option_values c, fnd_user d
where a.application_id=c.application_id and
a.PROFILE_OPTION_ID = c.PROFILE_OPTION_ID and
a.PROFILE_OPTION_NAME = b.PROFILE_OPTION_NAME and
c.level_id=10004 and c.level_value=d.user_id and
b.language = 'US' and
d.end_date is  null
and user_name= UPPER('&User_Name')
/
