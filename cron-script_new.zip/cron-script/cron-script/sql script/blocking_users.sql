col user_name for a14
col blocking_others for a10
col process for a10
Col user_form_name for a30 truncate
Set feed off verify off pages 0

select 
c.user_name, 
a.blocking_others, 
b.process, 
c.user_form_name 
from dba_locks a, v$session b, fnd_form_sessions_v c
where 
a.session_id=b.sid 
and b.serial#=c.serial# 
and a.blocking_others = 'Blocking';

