-- SQL> l
--   1  select distinct 'alter index msc.'||b.index_name||' rebuild partition '||partition_name||' online nologging parallel ;'
--   2  from dba_indexes a, dba_ind_partitions b
--   3  where a.index_name=b.index_name and table_owner='MSC' and table_name in
--   4* ('MSC_SYSTEM_ITEMS', 'MSC_ROUTINGS')
-- SQL> /
-- 
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_ROUTINGS_N1 rebuild partition ROUTINGS_999999 online nologging parallel ;                                     
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_ROUTINGS_N1 rebuild partition ROUTINGS_0 online nologging parallel ;                                          
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_ROUTINGS_U1 rebuild partition ROUTINGS__1 online nologging parallel ;                                         
alter index msc.MSC_ROUTINGS_N1 rebuild partition ROUTINGS__1 online nologging parallel ;                                         
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_N4 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_ROUTINGS_U1 rebuild partition ROUTINGS_0 online nologging parallel ;                                          
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_N1 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_N5 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_SYSTEM_ITEMS_N6 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_N2 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS__1 online nologging parallel ;                                 
alter index msc.MSC_SYSTEM_ITEMS_U3 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_ROUTINGS_U1 rebuild partition ROUTINGS_999999 online nologging parallel ;                                     
alter index msc.MSC_SYSTEM_ITEMS_U2 rebuild partition SYSTEM_ITEMS_999999 online nologging parallel ;                             
alter index msc.MSC_SYSTEM_ITEMS_U1 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  
alter index msc.MSC_SYSTEM_ITEMS_N3 rebuild partition SYSTEM_ITEMS_0 online nologging parallel ;                                  

